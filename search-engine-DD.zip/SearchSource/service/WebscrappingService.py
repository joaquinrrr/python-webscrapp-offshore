import json
import time
import logging
import math
import warnings
import requests
import pandas as pd
import os
import io
import re
import urllib
import cloudscraper
import xml.etree.ElementTree as ET
import numpy as np
import unicodedata
import pdfplumber
import ezodf
import shutil
from fake_useragent import UserAgent

from bs4 import BeautifulSoup
from datetime import datetime as dt, timedelta
from urllib.parse import urlparse, parse_qs
#from datetime import datetime
from typing import Optional, Dict
from urllib.parse import quote, urljoin
from io import StringIO, BytesIO
from PyPDF2 import PdfReader
from unidecode import unidecode

#Date
today = dt.today().date()
yesterday = dt.today().date() - timedelta(days = 1)
now = dt.now().strftime('%Y-%m-%d_%H-%M-%S')

#Disabling Warnings
warnings.filterwarnings("ignore")

#Connection Agent
header = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36'}


# UTILS
def save_to_csv(website_name: str, keyword: str, df: pd.DataFrame) -> None:
    '''
    output_dir = "./output"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    file_name = f"{website_name}_output_{keyword}_{now}.csv"
    file_path = os.path.join(output_dir, file_name)

    df.to_csv(file_path, index=False)
    '''
    file_name = f"{website_name}_output_{keyword}_{now}.csv"
    print(file_name+" TO DO -> Store the fetched data!")

def save_to_json(website_name: str, keyword: str, json_data: str) -> None:
    '''
    output_dir = "./output"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    now = dt.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"{website_name}_output_{keyword}_{now}.json"
    file_path = os.path.join(output_dir, file_name)

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(json_data)
    '''
    file_name = f"{website_name}_output_{keyword}_{now}.json"
    print(file_name+" TO DO -> Store the fetched data!")

def save_to_txt(text: str) -> None:
    output_dir = "./output"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    now = datetime.now().strftime("%Y%m%d_%H%M%S")  # formatted current date and time
    file_name = f"output_{now}.txt"
    file_path = os.path.join(output_dir, file_name)

    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(text)
    except Exception as e:
        print(f"An error occurred while trying to write to the file: {e}")

def get_soup(url: str, headers: dict, num_retries: int = 3) -> Optional[BeautifulSoup]:
    for _ in range(num_retries):
        try:
            response = requests.get(url, verify=False, headers=headers, timeout=30)
            if response.status_code == 200:
                return BeautifulSoup(response.content, 'html.parser')
        except (TimeoutError, ConnectionError, requests.exceptions.RequestException):
            pass
    return None

def get_soup2(url: str, headers: dict, num_retries: int = 3) -> Optional[BeautifulSoup]:
    try:
        response = requests.get(url, headers=header)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            return soup
        else:
            return None
    except Exception as e:
        print(f"Error occurred: {e}")
        return None

def get_extra_data(url: str, headers: dict, num_retries: int = 3) -> Optional[str]:
    for _ in range(num_retries):
        try:
            response = requests.get(url, verify=False, headers=headers, timeout=30)
            text = response.content.decode('utf-8')
            return re.findall(r'"description":(.*?), "articleBody"', text)[0].replace('"', '').strip()
        except (TimeoutError, ConnectionError, requests.exceptions.RequestException):
            pass
    return None

def datetime_to_str(obj):
    if isinstance(obj, dt):
        return obj.isoformat()
    else:
        return obj



def webscraping_gestion(key_word: str):
    base_url = f'https://gestion.pe/buscar/{key_word}/todas/descendiente/'
    page = 1
    num_retries = 3
    gestion_df = pd.DataFrame()
    loop_condition = True

    while loop_condition:
        soup = get_soup(f"{base_url}{page}", header, num_retries)
        if soup:
            news = []

            try:
                full_data = soup.find_all('div', {"class": "content-sidebar__left"})[0]
                main_data = re.findall(r'class="story-item__information-box w-full"(.*?)</div>', str(full_data))
                date_data = re.findall(r'class="story-item__top flex items-center md:flex-col md:items-start"(.*?)</div>', str(full_data))

                if main_data and date_data:
                    for i in range(len(main_data)):
                        date = re.findall(r'itemprop="description">(.*?)</p>', date_data[i])[0]

                        if '-' not in date or dt.strptime(date, '%Y-%m-%d').date() >= yesterday:
                            title = re.findall(r'itemprop="url">(.*?)</a>', main_data[i])[0]
                            link = 'https://gestion.pe' + re.findall(r'href="(.*?)/" itemprop="url">', main_data[i])[0]
                            article_description = get_extra_data(link, header, num_retries)

                            if article_description:
                                news.append([title, date, article_description, link])
                            print("Appending ", i)
                        else:
                            loop_condition = False
                else:
                    loop_condition = False

                df = pd.DataFrame(news, columns=['Title', 'Date', 'Summary', 'Link'])
                gestion_df = pd.concat([df, gestion_df], axis=0)

            except Exception as e:
                logging.error(f'Date: {today} - Error in Gestión Main Page Loop in Page Number {page} - Reason: {e}')

            page += 1
            time.sleep(1)

            if not soup or page == 3:
                gestion_df = pd.DataFrame(columns=['Title', 'Date', 'Summary', 'Link'])
                loop_condition = False
        else:
            loop_condition = False

    gestion_df.reset_index(drop=True, inplace=True)
    gestion_df['Source'] = 'Gestion'
    gestion_df['Category'] = f'{key_word}'
    gestion_df['Country'] = 'Peru'
    
    gestion_df = gestion_df[['Title', 'Date', 'Country', 'Source', 'Category', 'Summary', 'Link']]
    
    # Removing duplicates
    gestion_df.drop_duplicates(inplace=True)

    save_to_csv("Gestion", key_word, gestion_df)

    return gestion_df

def webscraping_peru21(key_word: str):
    
    #Base Url Format    
    url= f'https://peru21.pe/buscar/{key_word}/todas/descendiente/'
    
    #Pagination
    page = 1
    
    #Retry
    num_retries = 3
    
    #Settings
    peru21_df = pd.DataFrame()
    loop_condition = True
    
    while loop_condition == True:
        
        #Website
        for num in range(num_retries):
            try:
                site = url + str(page)
                response = requests.get(site, verify = False, headers = header, timeout = 30)
                soup = BeautifulSoup(response.content, 'html.parser')
                if response.status_code == 200:
                    break
            except (TimeoutError, ConnectionError, requests.exceptions.RequestException):
                if num == num_retries - 1:
                    break
                else:
                    pass
        
        #Empty List
        news = []
        
        try: 
            full_data = soup.find_all('div',{"class":"paginated-list paginated-list--search"})
            main_data = re.findall(r'class="story-item__information-box w-full"(.*?)</div>', str(full_data))
            date_data = re.findall(r'class="story-item__top flex items-center md:flex-col md:items-start"(.*?)</div>', str(full_data))
            
            if len(main_data) > 0 and len(date_data) > 0:
                for i in range(len(main_data)):
                    date = re.findall(r'itemprop="description">(.*?)</p>', date_data[i])[0]
                    if '-' not in date or dt.strptime(date, '%Y-%m-%d').date() >= yesterday: 
                        title = re.findall(r'itemprop="url">(.*?)</a>', main_data[i])[0]
                        link = 'https://peru21.pe'+re.findall(r'href="(.*?)" itemprop', main_data[i])[0]
                        
                        for num in range(num_retries):
                            try:    
                                response = requests.get(link, verify = False, headers = header, timeout = 30)
                                text = response.content.decode('utf-8')         
                                article_description = re.findall(r'"description":(.*?), "articleBody"', text)[0].replace('"', '').strip()
                                break
                            except (TimeoutError, ConnectionError, requests.exceptions.RequestException):
                                if num == num_retries - 1:
                                    break
                                else:
                                    pass
                                                 
                        #Appending Fields
                        news.append([title, date, article_description, link])
                    else:
                        loop_condition = False
            else:
                df = pd.DataFrame(columns = ['Title', 'Date', 'Summary', 'Link']) 
                loop_condition = False       
                
            #Appending results
            df = pd.DataFrame(news, columns = ['Title', 'Date', 'Summary', 'Link'])      
            peru21_df = pd.concat([df, peru21_df], axis = 0)
            
        except Exception as e:
            logging.error(f'Date: {today} - Error in Peru21 Main Page Loop in Page Number {page} - Reason: {e}')
        
        #Increasing page number
        page += 1
        time.sleep(1)
        
        if response.status_code != 200 or page == 3:
            peru21_df = pd.DataFrame(columns = ['Title', 'Date', 'Summary', 'Link']) 
            loop_condition = False 
    
    #Formating Output
    peru21_df.reset_index(drop = True, inplace = True)
    peru21_df['Source'] = 'Peru21'
    peru21_df['Category'] = f'{key_word}'
    peru21_df['Country'] = 'Peru'
    peru21_df = peru21_df[['Title', 'Date', 'Country', 'Source', 'Category', 'Summary', 'Link']]
    
    #Removing duplicas
    peru21_df.drop_duplicates(inplace = True)

    save_to_csv("Peru21", key_word, peru21_df)
    
    return peru21_df

# USA / INTERNATIONAL

#2a
def webscraping_office_of_foreign_assets_control(key_word: str):
    try:
        if not key_word:
            return json.dumps({"errorMessage": "An input keyword is needed for this service."})

        base_url = "https://sanctionssearch.ofac.treas.gov/"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
        }

        response = requests.get(base_url, headers=headers, verify=False)
        soup = BeautifulSoup(response.text, 'html.parser')

        ctl00_ctl03_HiddenField = soup.find('input', {'id': 'ctl00_ctl03_HiddenField'})['value']
        __VIEWSTATE = soup.find('input', {'id': '__VIEWSTATE'})['value']

        data = {
            'ctl00_ctl03_HiddenField': ctl00_ctl03_HiddenField,
            '__EVENTTARGET': '',
            '__EVENTARGUMENT': '',
            '__VIEWSTATE': __VIEWSTATE,
            '__VIEWSTATEGENERATOR': 'CA0B0334',
            'ctl00$MainContent$ddlType': '',
            'ctl00$MainContent$txtAddress': '',
            'ctl00$MainContent$txtLastName': key_word,
            'ctl00$MainContent$txtCity': '',
            'ctl00$MainContent$txtID': '',
            'ctl00$MainContent$txtState': '',
            'ctl00$MainContent$lstPrograms': '',
            'ctl00$MainContent$ddlCountry': '',
            'ctl00$MainContent$ddlList': '',
            'ctl00$MainContent$Slider1': '100',
            'ctl00$MainContent$Slider1_Boundcontrol': '100',
            'ctl00$MainContent$btnSearch': 'Search',
        }

        response_post = requests.post(base_url, headers=headers, data=data)
        response_text = response_post.text
        
        soup_post = BeautifulSoup(response_text, 'html.parser')

        table = soup_post.find('table', {'id': 'gvSearchResults'})

        # If table is None, return an empty list
        if table is None:
            return json.dumps([])

        rows_list = []
        rows = table.find_all('tr')

        # Check if the first row is a header row
        if rows[0].find('th'):
            rows = rows[1:]

        for row in rows:
            cols = row.find_all('td')

            row_dict = {
                'name': cols[0].text,
                'program': cols[3].text,
                'status': cols[4].text,
                'score': cols[5].text
            }
            rows_list.append(row_dict)
            
        df = pd.DataFrame(rows_list)

        if df.empty:
            return json.dumps([])

        #save_to_csv("webscraping_office_of_foreign_assets_control", key_word, df)

        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data
    
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})
    

#4a COMPLEX, TO BE FIXED. When reaching page 6, there is a blank row that truncates the code and fails.
def scraping_suplement_4_to_part_744_entity_list(key_word: str):
    base_url = 'https://www.bis.doc.gov/index.php/documents/regulations-docs/2326-supplement-no-4-to-part-744-entity-list-4/file'
    
    # Do a GET request to the URL. A PDF file will be retrieved.
    response = requests.get(base_url)

    dataframes = []  # A list to hold all dataframes
    
    # Open the PDF
    with pdfplumber.open(BytesIO(response.content)) as pdf:
        # Extract tables from the first three pages
        for i in range(5):
            page = pdf.pages[i]
            tables = page.extract_tables()

            for table in tables:
                # The table is a list of lists, where each inner list is a row in the table
                # Here, we'll convert each table into a DataFrame and append it to the list
                df = pd.DataFrame(table)
                
                # Remove the first row if it is the header row
                df.columns = df.iloc[0]
                df = df.iloc[1:]
                
                # Remove newline characters from each field
                df = df.applymap(lambda x: x.replace('\n', ' ') if isinstance(x, str) else x)
                
                dataframes.append(df)

    # Concatenate all the dataframes
    dataframes = [df.reset_index(drop=True) for df in dataframes]
    final_df = pd.concat(dataframes)
    save_to_csv("scraping_suplement_4_to_part_744_entity_list", key_word, final_df)
    return final_df

#6a
def scraping_fbi_wanted(key_word:str):
    try:
        page = 1
        df_list = []
        while page < 49:
            try:
                response = requests.get('https://api.fbi.gov/wanted/v1/list', params={
                    'page': page
                })
                data = json.loads(response.content)
                wanted_individuals = data['items']
                df = pd.DataFrame(wanted_individuals)
                df_list.append(df)
                page += 1
                logging.info(f"page {page}")

            except (json.JSONDecodeError, KeyError) as e:
                print(f"An error occurred: {e}")
                break
                
        if df_list:
            final_df = pd.concat(df_list)
            if key_word:
                final_df = final_df[final_df.apply(lambda row: row.astype(str).str.contains(key_word, case=False).any(), axis=1)]
            #save_to_csv("scraping_fbi_wanted", key_word, final_df)
            data_list = final_df.to_dict(orient='records')
            json_data = json.dumps(data_list)
            return json_data
        else:
            return json.dumps([])
            
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#1
def webscraping_worldbank_debarred_firms(key_word: str):

    url = 'https://apigwext.worldbank.org/dvsvc/v1.0/json/APPLICATION/ADOBE_EXPRNCE_MGR/FIRM/SANCTIONED_FIRM'
    page = 1
    num_retries = 3

    worldBank_df = pd.DataFrame()
    loop_condition = True

    header = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36', 'apikey':'z9duUaFUiEUYSHs97CU38fcZO7ipOPvm'}

    try:
        while loop_condition:

            for num in range(num_retries):
                try:
                    site = url
                    response = requests.get(site, verify=False, headers=header, timeout=30)
                    if response.status_code == 200:
                        break
                except (TimeoutError, ConnectionError, requests.exceptions.RequestException):
                    if num == num_retries - 1:
                        break
                    else:
                        pass

            data = response.json()
            if 'response' in data and 'ZPROCSUPP' in data['response']:
                zprocsupp_data = data['response']['ZPROCSUPP']
                filtered_data = []

                for item in zprocsupp_data:
                    if key_word.lower() in item['SUPP_NAME'].lower() or key_word.lower() in str(item['SUPP_ID']).lower() or key_word.lower() in item['COUNTRY_NAME'].lower() or key_word.lower() in item['UPD_USER'].lower():
                        filtered_data.append(item)

                worldBank_df = pd.DataFrame(filtered_data)
                worldBank_df['key_word'] = key_word

            loop_condition = False
            save_to_csv("webscraping_worldbank_debarred_firms", key_word, worldBank_df)
            data_list = worldBank_df.to_dict(orient='records')
            json_data = json.dumps(data_list)
            return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

# INTER AMERICAN DEVELOPMENT BANK
#2
def webscraping_iadb_sanctioned_firms_and_individuals(key_word: str):
    # Connection Agent
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
        'referer': 'https://www.iadb.org/en/transparency/sanctioned-firms-and-individuals'}
    try:
        response = requests.get('https://www.iadb.org/en/sanctioned-firms/get-santions/pPageNumber=1&pPageSize=100000&pLang=en',
                                verify=False, headers=header)
        data = pd.json_normalize(json.loads(response.content))
        
        # Filter rows containing the key_word in any column
        filtered_data = data[data.apply(lambda row: row.astype(str).str.contains(key_word, case=False).any(), axis=1)]
        
        if filtered_data.empty:
            return json.dumps([])

        save_to_csv("webscraping_iadb_sanctioned_firms_and_individuals", key_word, filtered_data)

        data_list = filtered_data.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data
        
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#3 PUBLIC COMPANY ACCOUNTING OVERSIGHT BOARD
def webscraping_pcaob_enforcement_actions(key_word: str):
    api_url = 'https://searchapi.hawksearch.com/api/v2/search/'
    max_per_page = 96

    payload = {
        "MaxPerPage": max_per_page,
        "CustomUrl": "/oversight/enforcement/settled-disciplinary-orders",
        "SearchWithin": '',
        "FacetSelections": {},
        "IndexName": "pcaob.20230221.232246.all-data-types",
        "ClientGuid": "e962e95324cb46ef8955c0b09a3904b9",
        "PageNo": 1
    }

    try:
        response = requests.post(api_url, json=payload, headers=header, verify=False)
        data = response.json()
        
        if response.status_code == 200:

            numberOfResults = data.get('Pagination').get('NofResults')
            number_of_pages = math.ceil(numberOfResults / max_per_page)

            all_records = []

            for page_no in range(1, number_of_pages + 1):
                payload["PageNo"] = page_no

                response = requests.post(api_url, json=payload, headers=header, verify=False)
                data = response.json()

                if response.status_code != 200:
                    print(f"Failed to fetch the content from page {page_no}. Error Code: {response.status_code}")
                    continue
                
                results = data.get("Results", [])
                
                for result in results:
                    document = result.get("Document", {})
                    name = document.get("title", [None])[0]
                    link = json.loads(document.get("enforcementorderdocument", ["{}"])[0]).get("mediaUrl")
                    types = document.get("enforcementordertypes", [None])[0]
                    country = document.get("country", [None])[0]
                    effective_date = document.get("effectivedate", [None])[0]

                    if name and link and types and country and effective_date:
                        all_records.append({"Name": name, "Link": link, "Types": types, "Country": country, "Effective Date": effective_date})

            df = pd.DataFrame(all_records)
            
            if key_word == "":
                pass
            else:
                df = df[df.apply(lambda row: row.astype(str).str.contains(key_word, case=False).any(), axis=1)]
            
            save_to_csv("webscraping_pcaob_enforcement_actions", key_word, df)

            data_list = df.to_dict(orient='records')
            json_data = json.dumps(data_list)
            return json_data
            
        else:
            logging.error(f"Failed to fetch the content from the URL. Error Code: {response.status_code}")
            return json.dumps({"error": f"Failed to fetch the content from the URL. Error Code: {response.status_code}"})

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})
    

#4
def webScraping_data_europa(key_word: str):

    try:
        with requests.Session() as s:
            header = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
            }
            response = s.get('https://data.europa.eu/api/hub/search/datasets/consolidated-list-of-persons-groups-and-entities-subject-to-eu-financial-sanctions', verify=False, headers=header)
            cookies = response.cookies
            time.sleep(1)

            # Getting data in site
            data = pd.json_normalize(json.loads(response.content))
            data = pd.json_normalize(data['result.distributions'][0])

            # Getting data URL
            data = data[data['media_type'] == 'text/csv'][['title.en', 'media_type', 'download_url']]
            url = data[data['title.en'] == max(data['title.en'])]['download_url'].str[0]
            url.reset_index(drop=True, inplace=True)

            # Downloading data
            response = s.get(url[0], verify=False, headers=header, cookies=cookies)
            content = response.content.decode()
            file = StringIO(content)
            data = pd.read_csv(file, sep=';')

            df = pd.DataFrame(data)
            filtered_df = pd.DataFrame()

            if key_word == "":
                filtered_df = df
            else:
                filtered_df = df[df.apply(lambda row: row.astype(str).str.contains(key_word).any(), axis=1)]

            # Replacing NaN values with an empty string
            filtered_df = filtered_df.replace({np.nan: ''})

            data_list = filtered_df.to_dict(orient='records')
            json_data = json.dumps(data_list, ensure_ascii=False)
            return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#5
def webscraping_offshore_leaks_database(key_word: str):
    try:
        base_url = 'https://offshoreleaks.icij.org'
        search_url = f'{base_url}/search?q={key_word}&c=&j=&d='
        num_retries = 3

        df = pd.DataFrame(columns=["Entity", "Jurisdiction", "Linked To", "Data From"])
        loop_condition = True

        while loop_condition:
            soup = get_soup(search_url, header, num_retries)

            if soup is None:
                break

            table = soup.find("table", class_="table table-sm table-striped search__results__table")

            if table is not None:
                rows = table.find_all("tr")

                for row in rows:
                    cols = row.find_all("td")

                    # Ensure that all variables have values or are set to 'null'
                    entity = cols[0].text.strip() if len(cols) > 0 else 'null'
                    jurisdiction = cols[1].text.strip() if len(cols) > 1 else 'null'
                    linked_to = cols[2].text.strip() if len(cols) > 2 else 'null'
                    data_from = cols[3].text.strip() if len(cols) > 3 else 'null'

                    if key_word.lower() in entity.lower() or key_word.lower() in jurisdiction.lower() or key_word.lower() in linked_to.lower() or key_word.lower() in data_from.lower():
                        new_row = pd.DataFrame({"Entity": [entity], "Jurisdiction": [jurisdiction], "Linked To": [linked_to], "Data From": [data_from]})
                        df = pd.concat([df, new_row], ignore_index=True)

            next_page = soup.find("div", id="more_results")

            try:
                if next_page is not None:
                    next_page_url = next_page.find('a')['href']
                    search_url = base_url + next_page_url
                    print("proceeding to next page...")
                else:
                    loop_condition = False
            except:
                loop_condition = False

        save_to_csv("webscraping_offshore_leaks_database", key_word, df)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#6 UNITED NATIONS SECURITY COUNCIL
def parse_info_from_table_row(row: str) -> dict:
    parsed_info = {
        'Permanent Reference Number': '',
        'Name': '',
        'Title': '',
        'Position': '',
        'Date of Birth': '',
        'Place of Birth': '',
        'Good Quality Alias': '',
        'Low Quality Alias': '',
        'Nationality': '',
        'Passport Number': '',
        'National ID Number': '',
        'Address': '',
        'Date of Inclusion': '',
        'Other Data': ''
    }

    match = re.search(r'^[A-Z]+\.\d+', row)
    if match:
        parsed_info['Permanent Reference Number'] = match.group()
    
    try:
        parsed_info['Name'] = re.search(r'Nombre:\s+((\d:\s+\w+\s+)+)', row).group(1)
    except:
        parsed_info['Name'] = ''

    try:
        parsed_info['Title'] = re.search(r'Título:\s+(.+?)\s+Cargo', row).group(1)
    except:
        parsed_info['Title'] = ''
    
    parsed_info['Position'] = re.search(r'Cargo:\s+(.+?)\s+Fecha de nacimiento', row).group(1)
    
    try:
        parsed_info['Date of Birth'] = re.search(r'Fecha de nacimiento:\s+(.+?)\s+Lugar de nacimiento', row).group(1)
    except AttributeError:
        parsed_info['Date of Birth'] = ''

    parsed_info['Place of Birth'] = re.search(r'Lugar de nacimiento:\s+(.+?)\s+Alias de buena calidad', row).group(1)
    parsed_info['Good Quality Alias'] = re.search(r'Alias de buena calidad:\s+(.+?)\s+Alias de baja calidad', row).group(1)
    parsed_info['Low Quality Alias'] = re.search(r'Alias de baja calidad:\s+(.+?)\s+Nacionalidad', row).group(1)
    parsed_info['Nationality'] = re.search(r'Nacionalidad:\s+(.+?)\s+Número de pasaporte', row).group(1)
    parsed_info['Passport Number'] = re.search(r'Número de pasaporte:\s+(.+?)\s+Número nacional de identidad', row).group(1)
    parsed_info['National ID Number'] = re.search(r'Número nacional de identidad:\s+(.+?)\s+Domicilio', row).group(1)
    parsed_info['Address'] = re.search(r'Domicilio:\s+(.+?)\s+Fecha de inclusión', row).group(1)
    parsed_info['Date of Inclusion'] = re.search(r'Fecha de inclusión:\s+(.+?)(\s+|\n)', row).group(1)
    
    try:
        parsed_info['Other Data'] = re.search(r'Otros datos:\s+(.+)', row).group(1)
    except AttributeError:
        parsed_info['Other Data'] = ''

    for key, value in parsed_info.items():
        value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('utf-8', 'ignore')
        value = re.sub(' +', ' ', value).strip()
        parsed_info[key] = value
    
    return parsed_info

def webscraping_united_nations_security_council_list(key_word: str, orderByPermanentReferenceNumber: bool = True):
    if orderByPermanentReferenceNumber:
        base_url = 'https://scsanctions.un.org/r-sp'
    else:
        base_url = 'https://scsanctions.un.org/consolidated-sp/'

    df = pd.DataFrame(columns=[
        'Permanent Reference Number', 'Name', 'Title', 'Position', 'Date of Birth',
        'Place of Birth', 'Good Quality Alias', 'Low Quality Alias', 'Nationality',
        'Passport Number', 'National ID Number', 'Address', 'Date of Inclusion',
        'Other Data'
    ])

    loop_condition = True
    #try:
    while loop_condition:
        soup = get_soup(base_url, header)

        if soup is None:
            break

        sanctions_table = soup.find("table", {"id": "sanctions"})
        rows = sanctions_table.find_all("tr", {"class": "rowtext"})

        for row in rows:
            td = row.find("td")
            row_text = td.get_text(separator=" ").replace("\n", " ").replace("\xa0", " ").strip()
            if key_word.lower() in row_text.lower():
                parsed_info = parse_info_from_table_row(row_text)
                df = pd.concat([df, pd.DataFrame([parsed_info])], ignore_index=True)

        loop_condition = False

    #save_to_csv("webscraping_united_nations_security_council_list", key_word, df)
    data_list = df.to_dict(orient='records')
    json_data = json.dumps(data_list, ensure_ascii = True)
    return json_data

    #except Exception as e:
    #    logging.error(f"An error occurred: {str(e)}")
    #    return json.dumps({"error": f"An error occurred: {str(e)}"})

#7
def webscraping_us_sec_fcpa_cases(key_word: str) -> Optional[pd.DataFrame]:
    base_url = "https://www.sec.gov/enforce/sec-enforcement-actions-fcpa-cases"

    # Initialize logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    try:
        # Send a GET request to the target URL
        response = requests.get(base_url, timeout=10)
        response.raise_for_status()

        # Check the response status
        if response.status_code != 200:
            logger.error(f"Failed to fetch data: Status code {response.status_code}")
            return None

        # Parse the HTML content
        soup = BeautifulSoup(response.content, "html.parser")

        # Extract the relevant data
        data = []
        for year_section in soup.find("div", class_="article-body").find_all("ul"):
            for item in year_section.find_all("li"):
                case_date = item.text.strip().split(" - ")[-1].split(" ")[-1].strip(")").strip()

                case_name = ""
                link = item.find("a")
                if link is not None:
                    case_name = link.text.strip()
                    case_url = "https://www.sec.gov" + link["href"]
                else:
                    case_name = ""
                    case_url = ""

                penalty = " ".join(item.text.strip().split(" - ")[0].split(" ")[-4:])

                if key_word.lower() in case_name.lower():
                    data.append({
                        "Date": case_date,
                        "Case Name": case_name,
                        "Case URL": case_url,
                        "Penalty": penalty
                    })

        # Create a DataFrame
        df = pd.DataFrame(data, columns=["Date", "Case Name", "Case URL", "Penalty"])
        #save_to_csv("webscraping_us_sec_fcpa_cases", key_word, df)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json.dumps(data_list)

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#8
def webscraping_interpol_red_notices(key_word: str):
    url_key_word = key_word.replace(" ", "%20")
    base_url = f"https://ws-public.interpol.int/notices/v1/red?&name={url_key_word}"

    try:
        # Send a GET request to the base_url
        response = requests.get(base_url)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Load JSON data from the response
            data = response.json()

            # Extract the 'notices' from the '_embedded' key
            notices = data['_embedded']['notices']

            # Create an empty DataFrame to store the scraped data
            df = pd.DataFrame(columns=["forename", "date_of_birth", "entity_id", "nationalities", "name", "url"])

            # Iterate through the notices and extract the required data
            for notice in notices:
                forename = notice.get("forename", "")
                date_of_birth = notice.get("date_of_birth", "")
                entity_id = notice.get("entity_id", "")
                nationalities = ", ".join(notice.get("nationalities", []))
                name = notice.get("name", "")
                url = notice["_links"]["self"]["href"]

                # Append the data to the DataFrame
                df.loc[len(df)] = [forename, date_of_birth, entity_id, nationalities, name, url]

            # Save the DataFrame to a CSV file
            save_to_csv("webscraping_interpol_red_notices", key_word, df)
            data_list = df.to_dict(orient='records')
            json_data = json.dumps(data_list)
            return json.dumps(data_list)
        else:
            print(f"Request failed with status code {response.status_code}")

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#9
def webscraping_us_dos_terrorist_exclusion_list(key_word: str):
    try:
        base_url = "https://www.state.gov/terrorist-exclusion-list/"

        # Add headers to make the request look like it's coming from a web browser
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

        # Send a GET request to the base_url with the headers
        response = requests.get(base_url, headers=headers)

        if response.status_code == 200:
            # Parse the response content with BeautifulSoup
            soup = BeautifulSoup(response.content, "html.parser")

            # Find the paragraph element containing the desired text
            target_paragraph = soup.find("p", string="Terrorist Exclusion List Designees (alphabetical listing)")

            # Find the unordered list element right after the target paragraph
            ul_element = target_paragraph.find_next("ul")

            # Extract all list items from the unordered list element
            li_elements = ul_element.find_all("li")

            # Create an empty DataFrame to store the scraped data
            df = pd.DataFrame(columns=["name"])

            # Iterate through the list items and filter them by the given keyword
            for li in li_elements:
                name = li.text.strip()

                # Filter the names by the given keyword (case insensitive)
                if key_word.lower() in name.lower():
                    df.loc[len(df)] = [name]

            #save_to_csv("webscraping_us_dos_terrorist_exclusion_list", key_word, df)
            data_list = df.to_dict(orient='records')
            json_data = json.dumps(data_list)
            return json_data
        else:
            print(f"Request failed with status code {response.status_code}")
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#10a
def webscraping_us_dos_foreign_terrorist_organizations_designated_foreign_terrorist_organizations(key_word: str):
    try:
        base_url = "https://www.state.gov/foreign-terrorist-organizations/"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

        response = requests.get(base_url, headers=headers)
        soup = BeautifulSoup(response.content, "html.parser")

        tables = soup.find_all("table")
        
        # Extract the Designated Foreign Terrorist Organizations table
        designated_table = tables[0]
        df1 = pd.read_html(str(designated_table))[0]
        df1 = df1[df1["Name"].str.contains(key_word, case=False)]

        #save_to_csv("webscraping_us_dos_foreign_terrorist_organizations_designated_foreign_terrorist_organizations", key_word, df1)
        data_list = df1.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#10b
def webscraping_us_dos_foreign_terrorist_organizations_delisted_foreign_terrorist_organizations(key_word: str):
    try:
        base_url = "https://www.state.gov/foreign-terrorist-organizations/"

        # Add headers to make the request look like it's coming from a web browser
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

        response = requests.get(base_url, headers=headers)
        soup = BeautifulSoup(response.content, "html.parser")

        tables = soup.find_all("table")

        # Extract the Delisted Foreign Terrorist Organizations table
        delisted_table = tables[1]
        df2 = pd.read_html(str(delisted_table))[0]
        df2 = df2[df2["Name"].str.contains(key_word, case=False)]

        #save_to_csv("webscraping_us_dos_foreign_terrorist_organizations_delisted_foreign_terrorist_organizations", key_word, df2)
        data_list = df2.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#12a
def webscraping_us_ddtc_debarred_parties_statutory_debarments(key_word):
    try:
        base_url = 'https://www.pmddtc.state.gov/api/now/sp/page?id=ddtc_kb_article_page&sys_id=c22d1833dbb8d300d0a370131f9619f0&portal_id=f7dedc001b6db81085c10d08ec4bcb1e&request_uri=%2Fddtc_public%3Fid%3Dddtc_kb_article_page%26sys_id%3Dc22d1833dbb8d300d0a370131f9619f0'
        headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36'}
        main_page = requests.get(base_url, verify = False, headers = headers)

        #Getting CSVs
        data = json.loads(main_page.text)
        
        csv_urls = data['result']['containers'][1]['rows'][0]['columns'][0]['widgets'][0]['widget']['data']['text']
        soup = BeautifulSoup(csv_urls, 'html.parser')
        
        # Find all <a> tags
        csv_urls = soup.find_all('a', {'title':'CSV Format'})
        
        # Extract href values
        href_values = [tag['href'] for tag in csv_urls]
        
        full_data = []
        
        for link in href_values:
            csv_data = requests.get(f'https://www.pmddtc.state.gov/{link}', verify = False, headers = headers)
            
            try:
                csv_data = io.StringIO(csv_data.content.decode('utf-8'))
            except UnicodeDecodeError:
                csv_data = io.StringIO(csv_data.content.decode('latin1'))

            csv_data = pd.read_csv(csv_data)
            
            # Fill NaN with empty strings 
            csv_data = csv_data.fillna("")
            
            full_data.append(csv_data)

        if key_word:
            # Here's the modification for case-insensitive matching
            full_data[0] = full_data[0][full_data[0].apply(lambda row: row.astype(str).str.contains(key_word, case=False).any(), axis=1)]

        data_list = full_data[0].to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data
        
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})
        
#12b
def webscraping_us_ddtc_debarred_parties_administrative_debarments(key_word):
    try:
        base_url = 'https://www.pmddtc.state.gov/api/now/sp/page?id=ddtc_kb_article_page&sys_id=c22d1833dbb8d300d0a370131f9619f0&portal_id=f7dedc001b6db81085c10d08ec4bcb1e&request_uri=%2Fddtc_public%3Fid%3Dddtc_kb_article_page%26sys_id%3Dc22d1833dbb8d300d0a370131f9619f0'
        headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36'}
        main_page = requests.get(base_url, verify=False, headers=headers)

        # Getting CSVs
        data = json.loads(main_page.text)
        
        csv_urls = data['result']['containers'][1]['rows'][0]['columns'][0]['widgets'][0]['widget']['data']['text']
        soup = BeautifulSoup(csv_urls, 'html.parser')
        
        # Find all <a> tags
        csv_urls = soup.find_all('a', {'title':'CSV Format'})
        
        # Extract href values
        href_values = [tag['href'] for tag in csv_urls]
        
        full_data = []
        print("href values:", href_values)
        
        for link in href_values:
            csv_data = requests.get(f'https://www.pmddtc.state.gov/{link}', verify=False, headers=headers)

            try:
                csv_data = io.StringIO(csv_data.content.decode('utf-8'))
            except UnicodeDecodeError:
                csv_data = io.StringIO(csv_data.content.decode('latin1'))

            csv_data = pd.read_csv(csv_data)
            full_data.append(csv_data)

        if key_word:
            key_word_lower = key_word.lower()
            full_data[1] = full_data[1][full_data[1].apply(lambda row: row.astype(str).str.lower().str.contains(key_word_lower).any(), axis=1)]

        data_list = full_data[1].to_dict(orient='records')

        # Replace NaN values with empty strings
        for item in data_list:
            for key, value in item.items():
                if isinstance(value, float) and math.isnan(value):
                    item[key] = ""

        json_data = json.dumps(data_list)
        return json_data
    
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#13
def webscraping_us_bis_denied_persons_list(key_word: str):
    try:
        base_url = "https://www.bis.doc.gov/dpl/dpl.txt"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }
        
        response = requests.get(base_url, headers=headers)
        content = response.text
        lines = content.split('\n')

        data = []
        for line in lines[1:]:
            elements = line.split('\t')
            if len(elements) == 12:
                elements = [element.strip().strip('\"') for element in elements]  # Remove quotes from the strings
                data.append(elements)

        df = pd.DataFrame(data, columns=['Name', 'Street_Address', 'City', 'State', 'Country', 'Postal_Code', 'Effective_Date', 'Expiration_Date', 'Standard_Order', 'Last_Update', 'Action', 'FR_Citation'])

        def contains_keyword(row):
            for col in df.columns:
                if key_word.lower() in row[col].lower():
                    return True
            return False

        df_filtered = df[df.apply(contains_keyword, axis=1)]

        save_to_csv("webscraping_us_bis_denied_persons_list", key_word, df_filtered)
        data_list = df_filtered.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#14
def webscraping_uk_financial_sanctions_consolidated_list_of_targets(key_word: str):
    try:
        base_url = "https://ofsistorage.blob.core.windows.net/publishlive/2022format/ConList"

        csv_url = f"{base_url}.csv"

        response = requests.get(csv_url)

        if response.status_code == 200:
            csv_content = response.content.decode('utf-8')
            csv_content = '\n'.join(csv_content.split('\n')[1:])

            df = pd.read_csv(io.StringIO(csv_content))
            df = df.fillna('')

            if key_word != "":
                df = df[df.apply(lambda row: row.astype(str).str.contains(key_word, case=False).any(), axis=1)]

            save_to_csv("webscraping_uk_financial_sanctions_consolidated_list_of_targets", key_word, df)
            data_list = df.to_dict(orient='records')
            json_data = json.dumps(data_list)
            return json_data
        else:
            print(f"Failed to fetch the content from the URL. Error Code: {response.status_code}")
            json.dumps([])

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#15
def webscraping_ofac_china_sanctions_list(key_word:str):
    try:
        base_url = "https://sanctionssearch.ofac.treas.gov/"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
        }

        response = requests.get(base_url, headers=headers, verify=False)
        soup = BeautifulSoup(response.text, 'html.parser')

        ctl00_ctl03_HiddenField = soup.find('input', {'id': 'ctl00_ctl03_HiddenField'})['value']
        __VIEWSTATE = soup.find('input', {'id': '__VIEWSTATE'})['value']

        data = {
            'ctl00_ctl03_HiddenField': ctl00_ctl03_HiddenField,
            '__EVENTTARGET': '',
            '__EVENTARGUMENT': '',
            '__VIEWSTATE': __VIEWSTATE,
            '__VIEWSTATEGENERATOR': 'CA0B0334',
            'ctl00$MainContent$ddlType': '',
            'ctl00$MainContent$txtAddress': '',
            'ctl00$MainContent$txtLastName': '',
            'ctl00$MainContent$txtCity': '',
            'ctl00$MainContent$txtID': '',
            'ctl00$MainContent$txtState': '',
            'ctl00$MainContent$lstPrograms': 'CMIC-EO13959',
            'ctl00$MainContent$ddlCountry': '',
            'ctl00$MainContent$ddlList': '',
            'ctl00$MainContent$Slider1': '100',
            'ctl00$MainContent$Slider1_Boundcontrol': '100',
            'ctl00$MainContent$btnSearch': 'Search',
        }

        response_post = requests.post(base_url, headers=headers, data=data)
        response_text = response_post.text
        
        soup_post = BeautifulSoup(response_text, 'html.parser')
        
        table = soup_post.find('table', {'id': 'gvSearchResults'})

        rows_list = []
        
        for row in table.find_all('tr')[1:]:
            cols = row.find_all('td')

            row_dict = {
                'name': cols[0].text,
                'program': cols[3].text,
                'status': cols[4].text,
                'score': cols[5].text
            }
            rows_list.append(row_dict)
            
        df = pd.DataFrame(rows_list)
        
        # Filtering by keyword
        if key_word != "":
            df = df[df.apply(lambda row: row.astype(str).str.contains(key_word, case=False).any(), axis=1)]

        save_to_csv("webscraping_ofac_china_sanctions_list", key_word, df)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#16
'''
def webscraping_us_dos_nonproliferation_sanctions_list(key_word: str):
    base_url = "https://www.state.gov/key-topics-bureau-of-international-security-and-nonproliferation/nonproliferation-sanctions/"

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Language': 'en-US,en;q=0.9',
    }

    response = requests.get(base_url, headers=headers)
    soup = BeautifulSoup(response.content, "lxml")
    link_element = soup.find("a", class_="link-downloadable-content__link")

    if link_element:
        href_url = link_element["href"]
        print(f"The href URL is: {href_url}")

        # Download the PDF file
        pdf_response = requests.get(href_url, headers=headers)
        pdf_file = io.BytesIO(pdf_response.content)

        reader = PyPDF2.PdfReader(pdf_file)

        # Extract the table from each page and populate the DataFrame
        data = []
        for page_num in range(len(reader.pages)):
            with pdfplumber.open(pdf_file) as pdf:
                page = pdf.pages[page_num]
                table = page.extract_table()
                df_page = pd.DataFrame(table[1:], columns=table[0])
                df_page.reset_index(drop=True, inplace=True)
                data.append(df_page)

        # Concatenate the tables into a single DataFrame
        data = [df.reset_index(drop=True, inplace=True) for df in data]
        data = [df for df in data if df is not None]
        df = pd.concat(data, ignore_index=True)

        # Clean up the DataFrame
        df.columns = ['Sanction Name', 'Entity', 'Location of Entity', 'Date Imposed', 'Status/Date of Expiration', 'Federal Register Notice']
        df.dropna(subset=['Sanction Name'], inplace=True)
        df.reset_index(drop=True, inplace=True)

        print(df.head())

        # Save the DataFrame to a CSV file
        #df.to_csv('sanctions_data.csv', index=False)

        # Close the PDF file
        pdf_file.close()

    else:
        print("Could not find the desired link element")

def webscraping_us_dos_nonproliferation_sanctions_list(key_word: str):
    base_url = "https://www.state.gov/key-topics-bureau-of-international-security-and-nonproliferation/nonproliferation-sanctions/"

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Language': 'en-US,en;q=0.9',
    }

    response = requests.get(base_url, headers=headers)
    soup = BeautifulSoup(response.content, "lxml")
    link_element = soup.find("a", class_="link-downloadable-content__link")

    if link_element:
        href_url = link_element["href"]
        print(f"The href URL is: {href_url}")

        # Download the PDF file
        pdf_response = requests.get(href_url, headers=headers)
        pdf_file = BytesIO(pdf_response.content)

        # Extract text from the PDF file
        pdf_text = extract_text_from_pdf(pdf_file)

        # Process the extracted text and create a DataFrame
        data = process_pdf_text(pdf_text)
        df = pd.DataFrame(data)

        # Display the head of the DataFrame
        print(df.head())

    else:
        print("Could not find the desired link element")

def extract_text_from_pdf(pdf_file):
    print("INPUT PDF FILE", pdf_file)
    pdf_text = ""

    with pdfplumber.open(pdf_file) as pdf:
        num_pages = len(pdf.pages)

        for page_num in range(num_pages):
            pdf_text += pdf.pages[page_num].extract_text()

    return pdf_text

def process_pdf_text(text):
    print(text)
    # Remove unnecessary lines and spaces
    cleaned_text = re.sub(r'\n+', '\n', text)
    cleaned_text = re.sub(r' +', ' ', cleaned_text)

    # Extract data using regular expressions
    data_regex = re.compile(
        r'(Iran, North Korea, and Syria Nonproliferation Act Sanctions \(INKSNA\)|Executive Order \d{5})\s+(.*?)\s+([A-Za-z\s\(\),.]+?)\s+(\d{2}/\d{2}/\d{2,4})\s+(Expired on \d{2}/\d{2}/\d{2,4}|Lifted on \d{2}/\d{2}/\d{2,4}|Active)\s+(Vol\..+?Federal Register)',
        re.MULTILINE)
    matches = data_regex.findall(cleaned_text)

    # Process the matches and return a list of dictionaries
    data = []
    for match in matches:
        data.append({
            'Sanction Name': match[0].strip(),
            'Entity': match[1].strip(),
            'Location of Entity': match[2].strip(),
            'Date Imposed': match[3].strip(),
            'Status/Date of Expiration': match[4].strip(),
            'Federal Register Notice': match[5].strip(),
        })

    return data
'''

#17a
def webscraping_us_dos_executive_order_13224_counterterrorism_designated_individuals_and_entities(key_word: str):
    try:
        base_url = "https://www.state.gov/executive-order-13224/"

        # Add headers to make the request look like it's coming from a web browser
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

        response = requests.get(base_url, headers=headers)
        soup = BeautifulSoup(response.content, "html.parser")

        tables = soup.find_all("table")
        
        # Extract the Designated Individuals and Entities table
        designated_table = tables[0]
        df1 = pd.read_html(str(designated_table))[0]
        df1 = df1[df1["Name"].str.contains(key_word, case=False)]

        # Save the DataFrame to a CSV file
        #save_to_csv("webscraping_us_dos_executive_order_13224_counterterrorism_designated_individuals_and_entities", key_word, df1)
        data_list = df1.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#17b
def webscraping_us_dos_executive_order_13224_counterterrorism_delisted_individuals_by_dos(key_word: str):
    try:
        base_url = "https://www.state.gov/executive-order-13224/"

        # Add headers to make the request look like it's coming from a web browser
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

        response = requests.get(base_url, headers=headers)
        soup = BeautifulSoup(response.content, "html.parser")

        tables = soup.find_all("table")

        # Individuals Delisted by the Department of State table
        delisted_table = tables[1]
        df2 = pd.read_html(str(delisted_table))[0]
        df2 = df2[df2["Name"].str.contains(key_word, case=False)]

        # Save the DataFrame to a CSV file
        #save_to_csv("webscraping_us_dos_executive_order_13224_counterterrorism_delisted_individuals_by_dos", key_word, df2)
        data_list = df2.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#18
def webscraping_consolidated_list_of_persons_groups_or_entities_subject_to_EU_financial_sanctions(key_word:str):
    base_url = 'https://webgate.ec.europa.eu/fsd/fsf/public/files/csvFullSanctionsList_1_1/content?token=dG9rZW4tMjAxNw'

    try:
        response = requests.get(base_url, verify=False, headers=header)
        response.raise_for_status()

        # Create csv_file from response
        csv_file = StringIO(response.content.decode('utf-8-sig'))

        # Create DataFrame from csv_file
        csv_file.seek(0)  # Reset file pointer to beginning
        df = pd.read_csv(csv_file, delimiter=';')

        if key_word == "":
            pass
        else:
            df = df[df.apply(lambda row: row.astype(str).str.contains(key_word).any(), axis=1)]

        df = df.fillna("")
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except requests.HTTPError as http_err:
        logging.error(f'HTTP error occurred: {http_err}')
        return json.dumps({"error": f"HTTP error occurred: {http_err}"})
    except Exception as err:
        logging.error(f'Other error occurred: {err}')
        return json.dumps({"error": f"Other error occurred: {err}"})
        

# PERU
#20 TODO
def webscraping_sunat_consulta_ruc_por_razon_social(key_word: str):
    try:
        # First, encode the key_word for use in a URL
        encoded_key_word = quote(key_word)
        # Construct the base_url with the encoded key_word
        base_url = f"https://e-consultaruc.sunat.gob.pe/cl-ti-itmrconsruc/jcrS00Alias?razSoc={encoded_key_word}&accion=consPorRazonSoc"
        print("BASE URL", base_url)

        headers = {
            "Cookie": "ITMRCONSRUCSESSION=vGvWkTYPQfJKGT07m2Wn2JQr92nbJCDhvxW7vJFQb1WyyFwmJvdqJpGzHYnMjGx2DySmvTHCT2TlnTsxnfYkRgBnw1822GMQhDMY5nWL1XNQRHBSSH9MstH2KfJVcMCJypjWZ1QCbL2BpnMCbcKymvGfFTJn9nQNvYr2QdQwWqLtMnY9RNqS2QHgwmhvCwwlRltd6qHWQ1bK1LHlqZZJ2s4g8vd7LvLBYgB507bRXhxMvz90G4vMvCqTytvP5pbg!240493885!-82482700; TS01fda901=014dc399cba28f2b7493db0d05ba82d43d8d9752e7c84f9771518561297bb6d4930f7c22036b565c95b5458fd630731774d201493f1287b4a82be1a0b57481f604289b984b",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

        # Fetch the HTML content
        response = requests.post(base_url, headers=headers)
        html_content = response.text

        # Parse the HTML content using BeautifulSoup
        soup = BeautifulSoup(html_content, "html.parser")

        # Extract the data within <div class="list-group">
        list_group = soup.find("div", class_="list-group")
        results = list_group.find_all("a", class_="list-group-item clearfix aRucs")

        # Extract the required data and store it in a list of dictionaries
        data = []
        for result in results:
            ruc = result["data-ruc"]
            name = result.find("h4", class_="list-group-item-heading").find_next_sibling("h4").text
            ubicacion = result.find("p", class_="list-group-item-text").text.replace("Ubicaci&oacute;n: ", "")
            estado = result.find("span", class_="text-success").text

            data.append({
                "RUC": ruc,
                "Name": name,
                "Ubicación": ubicacion,
                "Estado": estado
            })

        # Convert the list of dictionaries to a DataFrame
        df = pd.DataFrame(data)

        #save_to_csv("webscraping_sunat_consulta_ruc_por_razon_social", key_word, df)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})


#24
def webscraping_osce_proveedores_inscritos(key_word: str): # key_word es RUC
    try:
        base_url = 'http://www.osce.gob.pe/consultasenlinea/rnp_consulta/ProveedoresInscritos.asp?action=enviar'
        
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "en-US,en;q=0.9,es;q=0.8",
            "Cache-Control": "max-age=0",
            "Connection": "keep-alive",
            "Content-Length": "55",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36 Edg/112.0.1722.64"
        }

        # Fetch the HTML content
        response = requests.post(base_url, headers = headers, verify = False, data = {'txtRuc': key_word, 'txtRnp': '', 'cmbCapitulo': '', 'cmbTipoPersona': ''})
        response.encoding = 'utf-8'

        # Parse the HTML content using BeautifulSoup
        soup = BeautifulSoup(response.content, "html.parser")

        table = soup.find_all('table')[2]  # La tabla que contiene los datos está en la tercera posición

        headers = ['RNP', 'RUC', 'NOMBRE/RAZËN SOCIAL', 'CAPITULO', 'PERSONA', 'F. APROB', 'VIGENCIA PARA SER PARTICIPANTE Y POSTOR - F. INI VIG.', 'VIGENCIA PARA SER PARTICIPANTE Y POSTOR - F. FIN VIG.', 'VIGENCIA PARA SER PARTICIPANTE, POSTOR Y CONTRATISTA - F. INI VIG.', 'VIGENCIA PARA SER PARTICIPANTE, POSTOR Y CONTRATISTA - F. FIN VIG.', 'ESTADO', 'TIENE O HA TENIDO SUSPENSIÓN EN SU VIGENCIA PARA SER PARTICIPANTE, POSTOR Y CONTRATISTA?', 'OBSERVACION']

        rows = table.find_all('tr')[2:]  # Excluye las dos primeras filas, que son los encabezados

        data = []
        for row in rows[:-1]:  # Excluye la última fila, que es la paginación
            columns = row.find_all('td', class_='TDData')
            data.append([col.text for col in columns])

        df = pd.DataFrame(data, columns=headers)
        df = df.iloc[1:]

        #save_to_csv('webscraping_osce_proveedores_inscritos', key_word, df)
        data_list = df.to_dict(orient='records')

        # normalize characters to utf-8 standard
        for record in data_list:
            for key, value in record.items():
                if isinstance(value, str):
                    record[key] = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode()

        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        print(e)
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})
        
#26
def webscraping_datosabiertos_oefa_registros_actos_administrativos(key_word: str):
    try:
        url = 'https://datosabiertos.oefa.gob.pe/rest/datastreams/290474/data.json/?limit=50&page=0'
        response = requests.get(url, verify = False, headers = header)
        data = json.loads(response.content)

        total_pages = math.ceil(data['fLength'] / 100)
        page_num = 0
        total_data = pd.DataFrame()

        while page_num <= total_pages:
            url = f'https://datosabiertos.oefa.gob.pe/rest/datastreams/290474/data.json/?limit=100&page={page_num}'
            response = requests.get(url, verify = False, headers = header)
            data = json.loads(response.content)
            df = pd.json_normalize(data['fArray'])
            values = []

            for i in range(30, len(df['fStr']) , 30):
                values.append(df['fStr'][i: i+30].to_list())

            clean_df = pd.DataFrame(values, columns = df['fStr'][0:30])

            #Concat
            total_data = pd.concat([total_data, clean_df], axis = 0)
            page_num += 1

        total_data.reset_index(inplace = True, drop = True)
        #save_to_csv("webscraping_datosabiertos_oefa_registros_actos_administrativos", "none", total_data)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        print(e)
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#28
def webscraping_jne_multas_electorales(key_word: str): # key_word as DNI...
    #try:
    header = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36'}

    #Getting Token
    anchorr = 'https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Leko_chAAAAACEVZ8PBGrQsZSg0E1-Xfg-OmOpu&co=aHR0cHM6Ly9tdWx0YXMuam5lLmdvYi5wZTo0NDM.&hl=en&v=4q6CtudrwcI-LSEYlfoEbDXg&size=invisible&cb=a3wcz2liyoe3'
    anchorr = anchorr.strip()
    keysite = anchorr.split('k=')[1].split("&")[0]

    
    var_co = anchorr.split("co=")[1].split("&")[0]
    var_v = anchorr.split("v=")[1].split("&")[0]

    r1 = requests.get(anchorr, verify = False, headers = header).text

    token1 = r1.split('recaptcha-token" value="')[1].split('">')[0]

    var_chr = '[33,38,19]'
    var_vh = '1745462459'
    var_bg = '!ZGKgYmcKAAQeGmlMbQEHDwCRiURVXlmXHZ9TCSlfERIjsyTARgOIpeHewrQLnCVAVL5jyCC5KR0Rs2xNnsdBlSxxajKD65K3_RMSnff7klmediZedqM__LotxLFYSq7pEoyxp9c_F8xG5iOQZLRZqLjQdIamd80Dhu145mAE9DdhE_kvNo0MweJyLT6MJkncRNpo9esOFG3M4G72OXG8ZPSk75wCIyIEm7Xr1IbachyXnuU1B1L1pdN9oJbNJCfRVMq_twvtAFVjSbxDAQLf9ITTLDG6LbjDnkOv_yXy4zDCP5B2YX72Dl4mtN5YqtYELrzgxN2O83Pu-CUK4negM-Qqju_kPoWY3c573EQAlo4yqyPAX3ttMOm2zRnclgbTCycS4uW-e8N1JKQrtY5bDojRYqfGIK1dNdwQONax9e3hE8y0SGHlsfw7Ol9ux8sUEC3UJSiEv5KXVcb5J3AgGJ9trp-WREkYdGTx721Owu5alGb0xK6bngviNzdkY1kRa4J6XIqXw97A6Pt9n9DtdUMQaqYNwYlCc5CRq0FzjS5gDL8v0E-SubDsztlMSu0St2N-X7ulhkv2PhJPGyelFnxOwB8kVXi1Ykd24wEHzk2jAfJExDg2zoSE2LAz99oIi_JzJX2XuSH1Xy7nvAR-xpm8b38odXRp1BEikGCTmoCTrk6zsN6BmwRdYwuIGW4nRER-02FC9EPs7SCctAk15jiqPiY1Kaj3UWeYVLQYKOA9nreSrjHWGck6MuqvgA9OpXnpGaSbHgrnQpmq2LjN00Tpd40Q9fCpFLNtkZjFxHG8tU2rW9pOCF5lXAskZShwCvZGLiJTmI6VjkhHUkwi3JGV1DsHRVvhI_e4_JUOnjGX4lOiVanSyv-iFiuK3N9M4AcnzBVQE82GPra8WUvBGys07o0C1E3hqZzCYPipEb2bs7A6yYCeA60'
    var_chr = urllib.parse.quote(var_chr)

    payload = {"v":var_v, "reason":"q", "c":token1, "k":keysite, "co":var_co,
    "hl":"en", "size":"invisible", "chr":var_chr, "vh":var_vh, "bg":var_bg
    }

    r2 = requests.post(f"https://www.google.com/recaptcha/api2/reload?k={keysite}", data = payload, verify = False, headers = header)

    try:
        token2 = str(r2.text.split('"rresp","')[1].split('"')[0])
    except:
        token2 = 'null'

    #Getting JNE Data
    jne_payload = {
    'Dni': f'{key_word}',
    'Token': f'{token2}',
    'Termino': '56421'
    }

    jne_header = {'Content-Type': 'application/json',
    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36'}

    response = requests.post('https://multas.jne.gob.pe/consult', json = jne_payload, verify = False, headers = jne_header)

    datos_json = json.loads(response.content)

    # Crear DataFrame a partir de los datos JSON
    print("DATOS JSON")
    print(datos_json)
    '''
    df = pd.DataFrame(datos_json["data"])
    
    if df.empty:
        print("No data found")
        return

    df = df[['dni', 'tipoOmision', 'procesoElectoral', 'codigoPago', 'nombre', 'multa', 'estado']]

    #save_to_csv("webscraping_jne_multas_electorales", key_word, df)
    data_list = df.to_dict(orient='records')
    json_data = json.dumps(data_list)
    return json_data
    '''

    #except Exception as e:
    #    print(e)
    #    logging.error(f"An error occurred: {str(e)}")
    #    return json.dumps({"error": f"An error occurred: {str(e)}"})

#29 JNE - REGISTRO DE ORGANIZACIONES POLITICAS - CONSULTA DETALLADA DE AFILIACION
def extract_data(soup):
    data = {}
    
    def clean_text(text):
        text = text.replace('\r\n', ' ').strip()
        text = re.sub(r'\s+', ' ', text)
        return text

    # Extracting subject's name
    subject_name = soup.find('p', {'id': 'divNombresCiudadano'})
    if subject_name:
        data['name'] = clean_text(subject_name.get_text())
    else:
        data['name'] = None

    # Extracting political organization's name
    organization_text = soup.find('span', {'style': 'color:firebrick'}, text=True)
    if organization_text:
        data['organization'] = clean_text(organization_text.get_text())
    else:
        data['organization'] = None

    # Extracting padrón data
    padron_si = soup.find('span', {'id': 'Panel_SiEstaPadron'})
    padron_no = soup.find('asp:panel', {'id': 'Panel_NoEstaPadron'})
    
    if padron_si and padron_si.get('style') != "display:none":
        data['padron'] = clean_text(padron_si.get_text())
    elif padron_no and padron_no.get('style') != "display:none":
        data['padron'] = clean_text(padron_no.get_text())
    else:
        data['padron'] = None

    # Extracting comité data
    comite_si = soup.find('span', {'id': 'Panel_SiEstaComite'})
    comite_no = soup.find('span', {'id': 'Panel_NoEstaComite'})

    if comite_si and comite_si.get('style') != "display:none":
        data['comite'] = clean_text(comite_si.get_text())
    elif comite_no and comite_no.get('style') != "display:none":
        data['comite'] = clean_text(comite_no.get_text())
    else:
        data['comite'] = None

    # Extracting dirigente/representante data
    representante_si = soup.find('span', {'id': 'Panel_SiEstaDirigentes'})
    representante_no = soup.find('span', {'id': 'Panel_NoEstaDirigentes'})

    if representante_si and representante_si.get('style') != "display:none":
        data['representante'] = clean_text(representante_si.get_text())
    elif representante_no and representante_no.get('style') != "display:none":
        data['representante'] = clean_text(representante_no.get_text())
    else:
        data['representante'] = None

    # Extracting positions held
    positions = []
    position_rows = soup.select('#Detalle_Repres tr')
    for row in position_rows:
        position = {}
        position_name = row.find('li')
        position_duration = row.find('em')
        
        if position_name and position_duration:
            position['name'] = clean_text(position_name.get_text())
            position['duration'] = clean_text(position_duration.get_text())
            positions.append(position)

    data['positions'] = positions

    return data

# key_word debe ser un RUC
def webscraping_registro_de_organizaciones_politicas_consulta_de_afiliacion(key_word: str):
    try:
        scraper = cloudscraper.create_scraper()

        #Disabling Warnings
        warnings.filterwarnings("ignore")

        #Connection Agent
        header = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36'}

        #Getting Token
        anchorr = 'https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Lf2WFslAAAAAAMFDdGOyifZ1D5ETJnV9Q6r4QIf&co=aHR0cHM6Ly9zcm9wcHVibGljby5qbmUuZ29iLnBlOjQ0Mw..&hl=en&v=1h-hbVSJRMOQsmO_2qL9cO0z&size=invisible&cb=3g1qp7pmyzda'
        anchorr = anchorr.strip()
        keysite = anchorr.split('k=')[1].split("&")[0]
        var_co = anchorr.split("co=")[1].split("&")[0]
        var_v = anchorr.split("v=")[1].split("&")[0]

        r1 = scraper.get(anchorr).text

        token1 = r1.split('recaptcha-token" value="')[1].split('">')[0]

        payload = {"v":var_v, "reason":"q", "c":token1, "k":keysite, "co":var_co,
        "hl":"en", "size":"invisible"}

        r2 = scraper.post(f"https://www.google.com/recaptcha/api2/reload?k={keysite}", data = payload)

        try:
            token2 = str(r2.text.split('"rresp","')[1].split('"')[0])
        except:
            token2 = 'null'

        #Getting Request Token
        r3 = scraper.get('https://sroppublico.jne.gob.pe/Consulta/Afiliado/Index')

        soup = BeautifulSoup(r3.content, 'html.parser', from_encoding='utf-8')
        request_token = soup.find(type="hidden")['value']

        jne_payload = {'__RequestVerificationToken': f'{request_token}',
        'DNI': f'{key_word}',
        'GoogleCaptchaToken': f'{token1}',
        'action': 'validate_captcha'}

        response = scraper.post('https://sroppublico.jne.gob.pe/Consulta/Afiliado/Index', data = jne_payload)

        soup = BeautifulSoup(response.content, 'html.parser', from_encoding='utf-8')
        
        # Extract data from soup
        data = extract_data(soup)

        json_data = json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False)
        
        # Convert json_data back to Python dict for comparison
        data_dict = json.loads(json_data)

        # Define the specific structure to check against
        check_structure = {
            "comite": None,
            "name": "",
            "organization": None,
            "padron": None,
            "positions": [],
            "representante": None
        }

        # Check if the data matches the structure
        if data_dict == check_structure:
            return json.dumps([])
        else:
            return json.dumps([json_data])
            
        
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})


#30 INDECOPI - BUSQUEDA DE DENUNCIAS Y SANCIONES POR RUC
def get_bearer_token_indecopi_denuncias_y_sanciones() -> str:
    url = "https://servicios.indecopi.gob.pe/appTodosServicioAutorizacion/oauth/token"
    form_data = {
        'username': 'appDPCMAQLCApi',
        'password': '$2a$10$Laxeuduj4o5aeGM/6kvBB.athJ4G8wrzd7TbUdn5a9.U4KA.lNQJO',
        'grant_type': 'password',
        'client_id': 'MIRA_AQL_COMPRAS',
        'client_secret': '$2a$10$MMOgVTLqxR4SE8maWi.y5.xrqAU4CSp0L3XjzyIe.hntv68pC7akG'
    }

    try:
        response = requests.post(url, data=form_data)
        if response.status_code == 200:
            json_data = response.json()
            bearer_token = json_data.get('access_token')
            if bearer_token:
                return bearer_token
            else:
                print("something is wrong! Couldn't find 'access_token' in the response.")
        else:
            print(f"Got status code {response.status_code} from the server. Reason: {response.reason}")
    except Exception as e:
        print(f"Oops! Something went wrong while trying to get the Bearer token. Details: {e}")

    return ""

def create_dataframe(json_data: dict) -> pd.DataFrame:
    try:
        # Extract the required attributes
        fecha_consulta = json_data.get('vcFechaConsulta', '')
        hora_consulta = json_data.get('vcHoraConsulta', '')
        rango_consulta = json_data.get('vcSubtitulo', '')

        lst_detalle_cabecera = json_data.get('lstDetalleCabecera', [])
        lst_sanciones = json_data.get('lstSanciones', [])
        sanciones_list = set()

        if lst_detalle_cabecera:
            detalle_cabecera = lst_detalle_cabecera[0]
            try:
                num_denuncias = int(detalle_cabecera.get('num_DENUNCIAS', 0))
            except ValueError:
                num_denuncias = float(detalle_cabecera.get('num_DENUNCIAS', 0))
            try:
                num_multas = int(detalle_cabecera.get('num_MULTAS', 0))
            except ValueError:
                num_multas = float(detalle_cabecera.get('num_MULTAS', 0))
            try:
                num_reclamos = int(detalle_cabecera.get('num_RECLAMOS', 0))
            except ValueError:
                num_reclamos = float(detalle_cabecera.get('num_RECLAMOS', 0))
            try:
                num_sanciones = int(detalle_cabecera.get('num_SANCIONES', 0))
            except ValueError:
                num_sanciones = float(detalle_cabecera.get('num_SANCIONES', 0))
            razon_social = detalle_cabecera.get('vc_RAZON_SOCIAL', '')

            sanciones = lst_sanciones
            # Iterate over lstSanciones and get unique vc_MATERIA - vc_HECHO_INFRACTOR combinations
            for sancion in sanciones:
                vc_materia = sancion.get('vc_MATERIA', '')
                vc_hecho_infractor = sancion.get('vc_HECHO_INFRACTOR', '')
                sanciones_list.add(f'{vc_materia} - {vc_hecho_infractor}')

        else:
            num_denuncias = 0
            num_multas = 0
            num_reclamos = 0
            num_sanciones = 0
            razon_social = ''

        # Create a pandas DataFrame
        data = {
            'FECHA DE CONSULTA': [fecha_consulta],
            'HORA DE CONSULTA': [hora_consulta],
            'RANGO DE CONSULTA': [rango_consulta],
            'NUMERO DE DENUNCIAS': [num_denuncias],
            'NUMERO DE SANCIONES': [num_sanciones],
            'MULTA (EN UITs)': [num_multas],
            'NUMERO DE RECLAMOS': [num_reclamos],
            'RAZON SOCIAL': [razon_social],
            'DETALLE MATERIA Y HECHO INFRACTOR': [sanciones_list]
        }
        df = pd.DataFrame(data)
        return df
    
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

def webscraping_indecopi_denuncias_y_sanciones(key_word: str):
    try:
        base_url = f'https://servicios.indecopi.gob.pe/appDPCMAQLCApi/api/detalleEmpresa?pNuDocumento={key_word}&pDtInicio=&pDtFin=&pChTipo=TD'
        bearer_token = get_bearer_token_indecopi_denuncias_y_sanciones()

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Authorization': f'Bearer {bearer_token}'
        }

        response = requests.get(base_url, headers=headers)

        if response.status_code == 200:
            try:
                json_data = response.json()
                df = create_dataframe(json_data)
                data_list = df.to_dict(orient='records')

                # Ensure no value is a set object
                for record in data_list:
                    for key, value in record.items():
                        if isinstance(value, set):
                            record[key] = None
                
                # validate if record is empty
                empty_record_keys = {
                    "NUMERO DE DENUNCIAS": 0,
                    "NUMERO DE SANCIONES": 0,
                    "MULTA (EN UITs)": 0,
                    "NUMERO DE RECLAMOS": 0,
                    "RAZON SOCIAL": "",
                    "DETALLE MATERIA Y HECHO INFRACTOR": None
                }

                # If all records are empty, return an empty list
                if all(all(record.get(key, None) == empty_record_keys.get(key, None) for key in empty_record_keys) for record in data_list):
                    return json.dumps([])

                # Add key_word to each record and ensure it is the first key
                for record in data_list:
                    record.update({'key_word': key_word})

                json_data = json.dumps(data_list)
                return json_data

            except ValueError as ve:
                print(f"Error: Unable to parse JSON data. Details: {ve}")
                return json.dumps({"error": f"Error: Unable to parse JSON data. Details: {ve}"})

        else:
            print(f"Error: Received status code {response.status_code} from the server. Reason: {response.reason}")
            return json.dumps({"error": f"Error: Received status code {response.status_code} from the server. Reason: {response.reason}"})

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error!!!": f"An error occurred: {str(e)}"})


#32 TODO
def webscraping_smv_personas_y_empresas_sancionadas(key_word: str):
    pass

#33
def webscraping_sbs_lavado_de_activos_procedimientos_sancionadores(key_word: str):
    try:
        base_url = 'https://www.sbs.gob.pe/prevencion-de-lavado-activos/Procedimientos-Sancionadores'

        session = requests.Session()

        headers = {
            "User-Agent": "PostmanRuntime/7.32.2",
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
        }

        response = session.get(base_url, headers=headers)

        if response.status_code != 200:
            print(f"Failed to fetch data: Status code {response.status_code}")
            return None

        soup = BeautifulSoup(response.content, "html.parser")

        # Locate the desired element and extract the href attribute
        link_element = soup.find("h2", text="Relación de Sancionados").find_next("a")
        link_href = quote(link_element["href"])  # URL encode the href
        logging.info(link_href)
        link_to_data = 'https://www.sbs.gob.pe'+link_href
        print("link ref:", link_href)

        # Download the Excel file
        response = session.get(link_to_data)

        if response.status_code != 200:
            print(f"Failed to fetch data: Status code {response.status_code}")
            return None

        file_type = response.headers.get('Content-Type', '')
        print(file_type)

        excel_data = BytesIO(response.content)

        # Reset the read pointer back to the start of the file
        excel_data.seek(0)

        if file_type in ['application/vnd.ms-excel', 'application/CDFV2']:
            df = pd.read_excel(excel_data, engine='xlrd', header=0)
        else:
            df = pd.read_excel(excel_data, engine='openpyxl', header=0)

        headers = df.columns[:9].tolist()

        if key_word != "":
            df = df[df.apply(lambda row: row.astype(str).str.contains(key_word, case=False).any(), axis=1)]
        else:
            pass

        data_list = df.to_dict(orient='records')

        data_list = [{k: datetime_to_str(v) for k, v in item.items()} for item in data_list]
        data_list = [{unidecode(str(k)): unidecode(str(v)) for k, v in item.items()} for item in data_list]
        data_list = [{k.replace('deg', ''): v for k, v in item.items()} for item in data_list] # replace 'deg' with '#'

        json_data = json.dumps(data_list)
        return json_data
    
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

# TODO
#34
def webscraping_gobierno_del_peru_relacion_de_funcionarios_o_servidores_sancionados(key_word: str):
    base_url = 'https://www.gob.pe/11909-acceder-a-la-relacion-de-funcionarios-o-servidores-sancionados'

    session = requests.Session()
    response = session.get(base_url)

    # Get the HTML content
    html_content = response.content

    # Create a BeautifulSoup object to parse the HTML
    soup = BeautifulSoup(html_content, 'html.parser')

    # Search for the anchor tag containing the desired href
    anchor_tag = soup.find('a', class_='track-ga-click', text=key_word)

    # Get the href attribute from the anchor tag
    href = anchor_tag['href'] if anchor_tag else None

    print(href)

#38 Proveedores Perú
def webscraping_buscador_proveedores_del_estado(key_word):
    try:
        key_word = urllib.parse.quote(key_word)
        base_url = f'https://eap.osce.gob.pe/perfilprov-bus/1.0/tarjetas?searchText={key_word}&pageSize=100&pageNumber=1&export=1&langTag=es'
        logging.info(base_url)
        main_page = requests.get(base_url, verify = False, headers = header)
        datos_json = json.loads(main_page.content)

        #Getting total records
        total = datos_json['searchInfo']
        total = total['hitsTotal']

        total_pages = math.ceil(total / 30)
        page_num = 1

        if datos_json['tarjetasProvT01'] and isinstance(datos_json['tarjetasProvT01'][0], dict):
            name_columns = list(datos_json['tarjetasProvT01'][0].keys())
        else:
            logging.warning("The expected data is not in the correct format.")
            return json.dumps([])
        
        results = []
        logging.info(f"Searching through page 1")
        while page_num <= total_pages:

            url = f'https://eap.osce.gob.pe/perfilprov-bus/1.0/tarjetas?searchText={key_word}&pageSize=100&pageNumber={page_num}&export=1&langTag=es'

            data_response = requests.get(url, verify = False, headers = header)
            data = json.loads(data_response.content)
            data = data['tarjetasProvT01']

            if data:
                for i in range(len(data)):
                    row_data = list(data[i].values())
                    results.append(row_data)
            else:
                logging.warning("No data retrieved from the source on page {page_num}.")
                break

            page_num += 1
            logging.info(f"Searching through page {page_num}")

        df = pd.DataFrame(results, columns = name_columns)

        # Filter DataFrame by key_word in each column
        if key_word != "":
            df = df[df.apply(lambda row: row.astype(str).str.contains(key_word, case=False, regex=False).any(), axis=1)]
        else:
            pass

        #save_to_csv('buscador_proveedores_del_estado', key_word, df)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        print(e)
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#39a
def webscraping_antecedentes_proveedores_general(key_word):
    try:
        with requests.session() as req:

            main_payload = {'paramPARAM_DNIRUC0':f'{key_word}',
            'path':'/public/ANTECEDENTES_PROVEEDORES/ANTECEDENTES_PROVEEDORES.cda',
            'dataAccessId':'QUERY_R_F0','outputIndexId':'1','pageSize':'0','pageStart':'0','paramsearchBox':''}

            get_cookie = req.get('https://bi.seace.gob.pe/pentaho/api/repos/:public:ANTECEDENTES_PROVEEDORES:ANTECEDENTES_PROVEEDORES.wcdf/generatedContent?userid=public&password=key', verify = False, headers = header)
            get_cookie = get_cookie.cookies.get_dict()
            get_cookie = ''.join(x + '=' + y for x, y in get_cookie.items())

            api_header = {'Host':'bi.seace.gob.pe', 'Origin':'https://bi.seace.gob.pe',
            'Cookie': f'{get_cookie}',
            'Referer': 'https://bi.seace.gob.pe/pentaho/api/repos/:public:ANTECEDENTES_PROVEEDORES:ANTECEDENTES_PROVEEDORES.wcdf/generatedContent?userid=public&password=key',
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
            'X-Requested-With': 'XMLHttpRequest'}

            main_response = req.post('https://bi.seace.gob.pe/pentaho/plugin/cda/api/doQuery?', headers = api_header, verify = False, data = main_payload)

            general_data = json.loads(main_response.content)

            col_names = []
            for i in range(len(general_data['metadata'])):
                col_names.append(general_data['metadata'][i]['colName'])

            results = []

            for i in range(len(general_data['resultset'])):
                results.append(general_data['resultset'][i])

            general_data_df = pd.DataFrame(results, columns = col_names)

        #save_to_csv('antecedentes_proveedores_general', key_word, general_data_df)
        data_list = general_data_df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        print(e)
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#39b
def webscraping_antecedentes_proveedores_vigencias(key_word):
    try:
        with requests.session() as req:
            get_cookie = req.get('https://bi.seace.gob.pe/pentaho/api/repos/:public:ANTECEDENTES_PROVEEDORES:ANTECEDENTES_PROVEEDORES.wcdf/generatedContent?userid=public&password=key', verify = False, headers = header)
            get_cookie = get_cookie.cookies.get_dict()
            get_cookie = ''.join(x + '=' + y for x, y in get_cookie.items())

            api_header = {'Host':'bi.seace.gob.pe', 'Origin':'https://bi.seace.gob.pe',
            'Cookie': f'{get_cookie}',
            'Referer': 'https://bi.seace.gob.pe/pentaho/api/repos/:public:ANTECEDENTES_PROVEEDORES:ANTECEDENTES_PROVEEDORES.wcdf/generatedContent?userid=public&password=key',
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
            'X-Requested-With': 'XMLHttpRequest'}

            vigencias_payload = {'paramPARAM_RUC':'f{key_word}',
            'path':'/public/ANTECEDENTES_PROVEEDORES/ANTECEDENTES_PROVEEDORES.cda',
            'dataAccessId':'QUERY_R_F3','outputIndexId':'1','pageSize':'0','pageStart':'0','paramsearchBox':''}

            vigencias_response = req.post('https://bi.seace.gob.pe/pentaho/plugin/cda/api/doQuery?', headers = api_header, verify = False, data = vigencias_payload)

            vigencias_data = json.loads(vigencias_response.content)

            col_names = []
            for i in range(len(vigencias_data['metadata'])):
                col_names.append(vigencias_data['metadata'][i]['colName'])

            results = []

            for i in range(len(vigencias_data['resultset'])):
                results.append(vigencias_data['resultset'][i])

            vigencias_data_df = pd.DataFrame(results, columns = col_names)
        
        #save_to_csv('antecedentes_proveedores_vigencias', key_word, vigencias_data_df)
        data_list = vigencias_data_df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        print(e)
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#39c
def webscraping_antecedentes_proveedores_detalles(key_word):
    try:
        with requests.session() as req:
            get_cookie = req.get('https://bi.seace.gob.pe/pentaho/api/repos/:public:ANTECEDENTES_PROVEEDORES:ANTECEDENTES_PROVEEDORES.wcdf/generatedContent?userid=public&password=key', verify = False, headers = header)
            get_cookie = get_cookie.cookies.get_dict()
            get_cookie = ''.join(x + '=' + y for x, y in get_cookie.items())

            api_header = {'Host':'bi.seace.gob.pe', 'Origin':'https://bi.seace.gob.pe',
            'Cookie': f'{get_cookie}',
            'Referer': 'https://bi.seace.gob.pe/pentaho/api/repos/:public:ANTECEDENTES_PROVEEDORES:ANTECEDENTES_PROVEEDORES.wcdf/generatedContent?userid=public&password=key',
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
            'X-Requested-With': 'XMLHttpRequest'}

            detalle_proveedores_payload = {'paramPARAM_RUC':f'{key_word}',
            'path':'/public/ANTECEDENTES_PROVEEDORES/ANTECEDENTES_PROVEEDORES.cda',
            'dataAccessId':'QUERY_R_F2_D','outputIndexId':'1','pageSize':'0','pageStart':'0','paramsearchBox':''}

            detalle_response = req.post('https://bi.seace.gob.pe/pentaho/plugin/cda/api/doQuery?', headers = api_header, verify = False, data = detalle_proveedores_payload)

            detalles_data = json.loads(detalle_response.content)

            col_names = []
            for i in range(len(detalles_data['metadata'])):
                col_names.append(detalles_data['metadata'][i]['colName'])

            results = []

            for i in range(len(detalles_data['resultset'])):
                results.append(detalles_data['resultset'][i])

            detalles_data_df = pd.DataFrame(results, columns = col_names)
        
        #save_to_csv('antecedentes_proveedores_detalles', key_word, detalles_data_df)
        data_list = detalles_data_df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        print(e)
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#39d
def webscraping_antecedentes_proveedores_adjudicaciones(key_word):
    try:
        with requests.session() as req:
            get_cookie = req.get('https://bi.seace.gob.pe/pentaho/api/repos/:public:ANTECEDENTES_PROVEEDORES:ANTECEDENTES_PROVEEDORES.wcdf/generatedContent?userid=public&password=key', verify = False, headers = header)
            get_cookie = get_cookie.cookies.get_dict()
            get_cookie = ''.join(x + '=' + y for x, y in get_cookie.items())

            api_header = {'Host':'bi.seace.gob.pe', 'Origin':'https://bi.seace.gob.pe',
            'Cookie': f'{get_cookie}',
            'Referer': 'https://bi.seace.gob.pe/pentaho/api/repos/:public:ANTECEDENTES_PROVEEDORES:ANTECEDENTES_PROVEEDORES.wcdf/generatedContent?userid=public&password=key',
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
            'X-Requested-With': 'XMLHttpRequest'}

            adjudicaciones_payload = {'paramPARAM_RUC':f'{key_word}',
            'path':'/public/ANTECEDENTES_PROVEEDORES/ANTECEDENTES_PROVEEDORES.cda',
            'dataAccessId':'QUERY_R_F5_D_BK14112021','outputIndexId':'1','pageSize':'0','pageStart':'0','paramsearchBox':''}
            
            adjudicaciones_response = req.post('https://bi.seace.gob.pe/pentaho/plugin/cda/api/doQuery?', headers = api_header, verify = False, data = adjudicaciones_payload)

            adjudicaciones_data = json.loads(adjudicaciones_response.content)

            col_names = []
            for i in range(len(adjudicaciones_data['metadata'])):
                col_names.append(adjudicaciones_data['metadata'][i]['colName'])

            results = []

            for i in range(len(adjudicaciones_data['resultset'])):
                results.append(adjudicaciones_data['resultset'][i])

            adjudicaciones_data_df = pd.DataFrame(results, columns = col_names)
        
        #save_to_csv('antecedentes_proveedores_adjudicaciones', key_word, adjudicaciones_data_df)
        data_list = adjudicaciones_data_df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

    except Exception as e:
        print(e)
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#40 NOT WORKING YET! TODO
def webscraping_busqueda_jurisprudencia(key_word): 
    url = "https://jurisprudencia.pj.gob.pe/jurisprudenciaweb/faces/page/inicio.xhtml"
    
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9,es;q=0.8",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": "jurisprudencia.pj.gob.pe",
        "Origin": "https://jurisprudencia.pj.gob.pe",
        "Referer": url,
        "sec-ch-ua": "\"Microsoft Edge\";v=\"113\", \"Chromium\";v=\"113\", \"Not-A.Brand\";v=\"24\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.42"
    }

    response = requests.get(url, headers=headers)
    if response.status_code == 200:

        soup = BeautifulSoup(response.content, 'html.parser')
        view_state = soup.find('input', {'name': 'javax.faces.ViewState'}).get('value')

        form_data = {
            'formBuscador: formBuscador': '',
            'javax.faces.ViewState': view_state, # Add the ViewState value here
            'formBuscador:tabpanel-value': 'general',
            'formBuscador:txtBusqueda': key_word,
            'formBuscador:buCorte': '1',
            'formBuscador:buDistrito': '0',
            'formBuscador:buEspecialidad': '0',
            'formBuscador:buSala': '0',
            'formBuscador:buNroExpediente': 'Ingrese Nro de Expediente XXXXXX',
            'formBuscador:j_idt31': 'formBuscador:j_idt31',
            'forward': 'buscar',
            'busqueda': 'especializada',
            'formBuscador:j_idt34': '21',
            'formBuscador:j_idt35': 'DESC',
            'formBuscador:j_idt36': 'Principal',
            'formBuscador:j_idt37': '1'
        }

        form_data = {
            'formBuscador: formBuscador': '',
            'javax.faces.ViewState': view_state, # Add the ViewState value here
            'formBuscador:tabpanel-value': 'general',
            'formBuscador:txtBusqueda': key_word,
            'formBuscador:buCorte': '1',
            'formBuscador:buDistrito': '0',
            'formBuscador:buEspecialidad': '0',
            'formBuscador:buSala': '0',
            'formBuscador:buPretensionDelitoSupValue': '',
            'formBuscador:buPretensionDelitoSupInput': '',
            'formBuscador:buPretensionValue': '',
            'formBuscador:buPretensionInput': '',
            'formBuscador:buPalabraClaveValue': '',
            'formBuscador:buPalabraClaveInput': '',
            'formBuscador:buNroExpediente': 'Ingrese Nro de Expediente XXXXXX',
            'formBuscador:buAnio': '',
            'formBuscador:j_idt31': 'formBuscador:j_idt31',
            'forward': 'buscar',
            'busqueda': 'especializada',
            'formBuscador:j_idt34': '21',
            'formBuscador:j_idt35': 'DESC',
            'formBuscador:j_idt36': 'Principal',
            'formBuscador:j_idt37': '1'
        }

        cookie = response.headers.get('Set-Cookie')
        headers['Cookie'] = cookie

        print("about to post_response")
        post_response = requests.post(url, headers=headers, data=form_data, allow_redirects=False)
        if post_response.status_code in range(300, 400):
            print("Redirection to: " + post_response.headers['Location'])
        elif post_response.status_code == 200:
            print("HERE!!!!!!!!!!!!!")
            print(post_response.text)
            return post_response.text
        else:
            print("Couldn't send the POST request")
            return "Couldn't send the POST request"
    else:
        return "Couldn't retrieve the webpage"

#41
def webscraping_sancionados_peru(key_word):
    try:
        warnings.filterwarnings("ignore")
        header = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36'}

        with requests.session() as req:
            response = requests.get('https://www.gob.pe/institucion/contraloria/informes-publicaciones', verify = False, headers = header)
            soup = BeautifulSoup(response.content, 'html.parser')
            area = soup.find('h3', {'aria-describedby': 'relacion-de-sanciones-inscritas-y-vigentes-description'})
            link = 'https://www.gob.pe' + area.a.get('href')

            data_response = requests.get(link, verify = False, headers = header)
            soup_response = BeautifulSoup(data_response.content, 'html.parser')
            soup_response = re.findall(r'href="(.*?).xlsx?', str(soup_response))
            links = list(set(soup_response))

            link_1 = links[0]
            link_2 = links[1]

            data_1 = requests.get(f'{link_1}.xlsx', verify = False, headers = header)
            data_2 = requests.get(f'{link_2}.xlsx', verify = False, headers = header)

            # Define column names for df_1
            column_names = ["#", "Nombres y Apellidos (1)", "DNI", "Infracción (2)", "Infracción (2) 2", "Infracción (2) 3", "Infracción (2) 4", "Sanción", "Plazo", "Resolución", "Vigencia de la Sanción (3) Fecha de Inicio", "Vigencia de la Sanción (3) Fecha de Término", "Entidad", "Ubicación"]

            # Initialize the lists
            data_list_df1 = []
            data_list_df2 = []

            with io.BytesIO(data_1.content) as fh:
                df_1 = pd.io.excel.read_excel(fh, sheet_name=0, skiprows=2, names=column_names)

                data_list_df1 = df_1.to_dict(orient='records')
                data_list_df1 = [{k: datetime_to_str(v) for k, v in item.items()} for item in data_list_df1[1:]]

            with io.BytesIO(data_2.content) as fh:
                df_2 = pd.io.excel.read_excel(fh, sheet_name=0, skiprows=1, names=column_names)

                data_list_df2 = df_2.to_dict(orient='records')
                data_list_df2 = [{k: datetime_to_str(v) for k, v in item.items()} for item in data_list_df2[2:]]

            # Merge both data lists
            merged_data = data_list_df1 + data_list_df2

            if key_word != "":
                keyword_lower = key_word.lower()
                filtered_data = [item for item in merged_data if any(keyword_lower in str(value).lower() for value in item.values())]
            else:
                filtered_data = merged_data

            json_data = json.dumps(filtered_data, ensure_ascii=False)
            return json_data

    except Exception as e:
        print(e)
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

# COLOMBIA

#42
def data_to_dataframe(data):
    df = pd.DataFrame(data)
    return df

def webscraping_sanciones_secop_colombia(key_word):
    try:
        base_url = "https://paco-api-prod.azure-api.net/paco/secop/contract/contractors/"
        params = {
            "start_year": 2017,
            "end_year": 2023,
            "limit": 10,
            "sort": "value",
            "order": "desc"
        }
        response = requests.get(base_url + key_word, params=params)
        if response.status_code == 200:
            data = data_to_dataframe(response.json())
            data_list = data.to_dict(orient='records')
            json_data = json.dumps(data_list)
            return json_data
        else:
            print(f"Error: Received status code {response.status_code} from the server. Reason: {response.reason}")
            return json.dumps({"error": f"Error: Received status code {response.status_code} from the server. Reason: {response.reason}"})

    except Exception as e:
        print(e)
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#44
def webscraping_migracion_colombia(key_word):
    base_url = "https://www.migracioncolombia.gov.co/buscar"
    params = {
        "q": key_word,
        "Search": ""
    }

    try:
        response = requests.get(base_url, params=params, verify=False)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')

            ul = soup.find('ul', {'class': 'search-results list-striped'})
            
            if ul == None:
                return json.dumps([])

            lis = ul.find_all('li')

            titles = []
            texts = []
            urls = []

            for li in lis:
                title = li.find('h4', {'class': 'result-title'}).text.strip()
                title = title.replace('“', "'").replace('”', "'") # replace curly double quotes with single quotes
                titles.append(title)
                
                text = li.find('p', {'class': 'result-text'})
                if text is not None:
                    text = text.text.strip().replace('“', "'").replace('”', "'") # replace curly double quotes with single quotes
                    texts.append(text)
                else:
                    texts.append(None)
                
                url = li.find('div', {'class': 'small result-url'}).text.strip()
                url = url.replace('“', "'").replace('”', "'") # replace curly double quotes with single quotes
                urls.append(url)

            df = pd.DataFrame({
                'Title': titles,
                'Text': texts,
                'URL': urls,
            })

            data_list = df.to_dict(orient='records')
            json_data = json.dumps(data_list, ensure_ascii=False)
            return json_data

        else:
            print(f"Error: Received status code {response.status_code} from the server. Reason: {response.reason}")
            return json.dumps({"error": f"Error: Received status code {response.status_code} from the server. Reason: {response.reason}"})

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#46
def webscraping_corte_constitucional_de_colombia(key_word):
    try:
        url = f"https://www.corteconstitucional.gov.co/secretaria/consultat/consulta.php?campo=rad_petic&date3=2019-01-01&date4=2023-03-31&radi=Radicados&palabra={key_word}&radi=radicados&todos=%25"
        response = requests.get(url, verify=False)

        if response.status_code != 200:
            print(f"Failed to fetch page: status code {response.status_code}")
            return

        soup = BeautifulSoup(response.content, 'html.parser')
        table = soup.find_all('table')[0]
        table_data = []

        for row in table.find_all('tr')[1:]:
            row_data = []
            for cell in row.find_all('td'):
                cell_data = ' '.join(element.text.replace('\n', ' ').replace('\r', ' ').replace(' :', ':').strip() for element in cell.find_all(text=True))
                row_data.append(cell_data)
            table_data.append(row_data)

        if not table_data:
            return json.dumps([])

        try:
            df = pd.DataFrame(table_data, columns=['Radicación', 'Demandante', 'Demandado', 'Primera Instancia', 'Segunda Instancia', 'Fecha Radicación'])
        except:
            return json.dumps([])

        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii=False)
        return json_data

    except requests.exceptions.RequestException as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#52
def webscraping_superintendencia_de_sociedades(key_word):
    try:

        if key_word == "":
            return json.dumps({"error": "Por favor ingrese un código NIT"})

        key_word = key_word[:9]

        url = "https://superwas.supersociedades.gov.co/ConsultaGeneralSociedadesWeb/ConsultaGeneral"

        data = {
            "action": "consultaPorNit",
            "nit": key_word
        }

        response = requests.post(url, data=data, verify=False)

        if response.status_code != 200:
            print(f"Failed to fetch page: status code {response.status_code}")
            return

        html_content = response.content.decode('ISO-8859-1')
        soup = BeautifulSoup(html_content, "html.parser")
        tables = soup.find_all('table')
        data_dict = {}

        for table in tables:
            for row in table.find_all('tr'):
                columns = row.find_all('th') + row.find_all('td')
                column_texts = [col.get_text().strip() for col in columns]
                # Add the data to the dictionary (key is the first column text, value is the second column text)
                if len(column_texts) == 2:
                    data_dict[column_texts[0]] = column_texts[1]

        # Validation step
        if data_dict.get("NIT") == "-" and all(value == "" for key, value in data_dict.items() if key != "NIT"):
            return json.dumps([])

        df = pd.DataFrame([data_dict])
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data

    except requests.exceptions.RequestException as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#53
def webscraping_entidades_vigiladas_por_la_superintendencia_financiera_de_colombia(key_word):
    try:
        url = 'https://www.superfinanciera.gov.co/inicio/industrias-supervisadas/entidades-vigiladas-por-la-superintendencia-financiera-de-colombia/lista-general-de-entidades-vigiladas-por-la-superintendencia-financiera-de-colombia-61694'
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        a_tags = soup.find_all('a')
        base_url = 'https://www.superfinanciera.gov.co'

        for tag in a_tags:
            title = tag.get('title')
            if title and 'Excel' in title:
                excel_url = base_url + tag.get('href')

                if excel_url.endswith('.xls'):
                    try:
                        df = pd.read_excel(excel_url, header=None, skiprows=14)
                        new_header = df.iloc[0:2].fillna('').apply(lambda row: ' '.join(row.values.astype(str)), axis=0)
                        df = df[2:]
                        df.columns = new_header
                        df = df.iloc[:, 1:16]
                        
                        df = df.fillna("")
                        
                        if key_word != "":
                            df = df[df.applymap(lambda x: key_word.lower() in str(x).lower()).any(axis=1)]
                            
                        data_list = df.to_dict(orient='records')

                        for record in data_list:
                            for key in record:
                                if isinstance(record[key], set):
                                    record[key] = list(record[key])
                                elif isinstance(record[key], str):
                                    record[key] = re.sub(" {2,}", " ", record[key])

                        if isinstance(data_list, set):
                            return json.dumps([])

                        json_data = json.dumps(data_list, ensure_ascii = False)
                        return json_data
                    
                    except Exception as e:
                        logging.error(f"Failed to read Excel file from {excel_url}. Error: {e}")
                        return json.dumps([])

                else:
                    logging.error(f"URL does not point to an Excel file: {excel_url}")
                    return json.dumps([])

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#56
def webscraping_sigep(key_word):
    try:

        if key_word == "":
            return json.dumps([])

        base_url = 'https://www.funcionpublica.gov.co/dafpIndexerBHV/hvSigep/index'
        next_page_url = base_url

        # Initialize a list to store the data
        data = []

        # Loop over each page
        while next_page_url:
            # Define form data
            form_data = {
                'bloquearFiltroDptoSeleccionado': '', 
                'bloquearFiltroEntidadSeleccionado': '', 
                'bloquearFiltroMunSeleccionado': '', 
                'bloquearFiltroTipoAltaSeleccionado': '', 
                'query': key_word, 
                'find': 'Search'
            }

            # Send POST request with form data
            response = requests.post(next_page_url, data=form_data)

            # Check if request was successful
            if response.status_code == 200:
                # Parse HTML response
                soup = BeautifulSoup(response.text, 'html.parser')

                # Extract data from the current page
                rows = soup.select('table.table-striped.table-hover tr')

                for row in rows:
                    person = {}
                    columns = row.select('td.columna-datos')
                    for column in columns:
                        links = column.select('a')
                        if links:
                            person['Name'] = links[0].get_text(strip=True)
                            person['Link'] = links[0]['href']

                        spans = column.select('span')
                        if spans:
                            person['Role'] = spans[1].get_text(strip=True)
                            person['Organization'] = spans[2].get_text(strip=True)
                            person['Location'] = spans[3].get_text(strip=True)
                            if len(spans) > 4:
                                person['Contact'] = spans[4].get_text(strip=True)

                    data.append(person)

                # Check for the next page url
                next_page_link = soup.find('a', attrs={'class': 'next_page'})

                # If a next page link is found, update next_page_url, else set it to None
                next_page_url = next_page_link['href'] if next_page_link else None

            else:
                logging.error(f"Failed to send POST request: {response.status_code}")
                return json.dumps(f"Failed to send POST request: {response.status_code}")

        # Create a DataFrame from the data
        df = pd.DataFrame(data)
        data_list = df.to_dict(orient='records')

        for record in data_list:
            for key in record:
                if isinstance(record[key], str):
                    record[key] = re.sub(r'[\r\n\t]', '', record[key])
        
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#57
def webscraping_dian(key_word:str):
    try:
        if key_word == "":
            return json.dumps({"error": "Por favor ingrese un código NIT"}, ensure_ascii = False)

        key_word = key_word[:9]

        with requests.session() as req:

            url = 'https://muisca.dian.gov.co/WebRutMuisca/DefConsultaEstadoRUT.faces'

            main_payload = {'vistaConsultaEstadoRUT:formConsultaEstadoRUT:numNit': key_word}

            get_cookie = req.get(url, verify = False, headers = header, data = main_payload)
            value_soup = BeautifulSoup(get_cookie.content, 'html.parser')
            value = value_soup.find('input', {'name':'com.sun.faces.VIEW'})['value']

            get_cookie = get_cookie.cookies.get_dict()
            get_cookie = ';'.join(x + '=' + y for x, y in get_cookie.items())

            api_header = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'Cookie': f'{get_cookie}',
                    'Host': 'muisca.dian.gov.co', 'Origin': 'https://muisca.dian.gov.co',
                    'Referer': 'https://muisca.dian.gov.co/WebRutMuisca/DefConsultaEstadoRUT.faces',
                    "User-Agent": "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36"}

            payload = {'vistaConsultaEstadoRUT:formConsultaEstadoRUT:modoPresentacionSeleccionBO': 'pantalla',
            'vistaConsultaEstadoRUT:formConsultaEstadoRUT:modoPresentacionFormBO': 'pantalla',
            'vistaConsultaEstadoRUT:formConsultaEstadoRUT:btnBuscar.x': '0',
            'vistaConsultaEstadoRUT:formConsultaEstadoRUT:btnBuscar.y': '0',
            'vistaConsultaEstadoRUT:formConsultaEstadoRUT:numNit': key_word,
            'com.sun.faces.VIEW': f'{value}',
            'vistaConsultaEstadoRUT:formConsultaEstadoRUT': 'vistaConsultaEstadoRUT:formConsultaEstadoRUT'}

            response = req.post(url, headers = api_header, verify = False, data = payload)
            soup = BeautifulSoup(response.content, 'html.parser')
            print(soup)
            results = []
            if len(key_word) == 9:
                try:
                    nit = key_word
                    razon_social = soup.find('span', id = 'vistaConsultaEstadoRUT:formConsultaEstadoRUT:razonSocial').get_text()
                    status = soup.find('span', id = 'vistaConsultaEstadoRUT:formConsultaEstadoRUT:estado').get_text()
                    results.append([nit, razon_social, status])
                except Exception:
                    nit = key_word
                    razon_social = 'No existen registros'
                    status = 'No existen registros'
                    results.append([nit, razon_social, status])
                df = pd.DataFrame(results, columns = ['NIT', 'Razón Social', 'Status'])
            else:
                try:
                    nit = key_word
                    primer_nombre = soup.find('span', id = 'vistaConsultaEstadoRUT:formConsultaEstadoRUT:primerNombre').get_text()
                    segundo_nombre = soup.find('span', id = 'vistaConsultaEstadoRUT:formConsultaEstadoRUT:otrosNombres').get_text()
                    nombres = primer_nombre + ' ' + segundo_nombre
                    primer_apellido = soup.find('span', id = 'vistaConsultaEstadoRUT:formConsultaEstadoRUT:primerApellido').get_text()
                    segundo_apellido = soup.find('span', id = 'vistaConsultaEstadoRUT:formConsultaEstadoRUT:segundoApellido').get_text()
                    apellidos = primer_apellido + ' ' + segundo_apellido
                    status = soup.find('span', id = 'vistaConsultaEstadoRUT:formConsultaEstadoRUT:estado').get_text()
                    results.append([nit, nombres, apellidos, status])
                except Exception:
                    nit = key_word
                    nombres = 'No existen registros'
                    apellidos = 'No existen registros'
                    status = 'No existen registros'
                    results.append([nit, nombres, apellidos, status])
                df = pd.DataFrame(results, columns = ['NIT', 'Nombres', 'Apellidos', 'Status'])
            
                # Validate if data was retrieved
                if df.iloc[0].drop("NIT").to_dict() == {"Nombres": "No existen registros", "Apellidos": "No existen registros", "Status": "No existen registros"}:
                    return json.dumps([])

            data_list = df.to_dict(orient='records')
            json_data = json.dumps(data_list, ensure_ascii = False)
            return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

'''
def webscraping_multas_y_sanciones_secop(key_word):
    url = 'https://www.datos.gov.co/resource/4n4q-k399.json'

    try:
        response = requests.get(url)
        response.raise_for_status()
        json_data = response.json()
        df = pd.json_normalize(json_data)
        df_filtered = df[df.apply(lambda row: key_word in row.astype(str), axis=1)]
        print(df_filtered)

    except requests.exceptions.HTTPError as errh:
        print ("Http Error:",errh)
    except requests.exceptions.ConnectionError as errc:
        print ("Error Connecting:",errc)
    except requests.exceptions.Timeout as errt:
        print ("Timeout Error:",errt)
    except requests.exceptions.RequestException as err:
        print ("Something went wrong with the request:",err)
    except Exception as e:
        print ("Something went wrong:",e)
'''

#58
def webscraping_multas_y_sanciones_secop(key_word:str):
    try:
        url = 'https://www.datos.gov.co/api/id/4n4q-k399.json?$select=`nombre_entidad`,`nit_entidad`,`nivel`,`orden`,`municipio`,`numero_de_resolucion`,`documento_contratista`,`nombre_contratista`,`numero_de_contrato`,`valor_sancion`,`fecha_de_publicacion`,`ruta_de_proceso`&$order=`:id`+ASC&$limit=10000000'

        dataframe = pd.DataFrame()
        with requests.session() as req:
            get_data = req.get(url, verify = False, headers = header)
            get_data = json.loads(get_data.content)
            for i in range(len(get_data)):
                df = pd.json_normalize(get_data[i])
                dataframe = pd.concat([df, dataframe], axis = 0)

        dataframe = dataframe.fillna("")

        mask = np.column_stack([dataframe[col].str.contains(key_word, case=False, na=False) for col in dataframe])
        filtered_dataframe = dataframe.loc[mask.any(axis=1)]

        data_list = filtered_dataframe.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#59
def webscraping_consulta_de_procesos_judiciales(key_word:str):
    try:
        base_url = "https://consultaprocesos.ramajudicial.gov.co:448/api/v2/Procesos/Consulta/NombreRazonSocial"
        
        data = []
        page = 1

        params = {
            'nombre': key_word,
            'tipoPersona': 'jur',
            'SoloActivos': 'true',
            'pagina': page
        }

        doStandardSearch = True

        response = requests.get(base_url, params=params, verify=False)
        if "Hay más de mil registros con los criterios especificados" in response.text:
            doStandardSearch = False

        if doStandardSearch == True:
            logging.info("do standard search")
            while True:

                params = {
                    'nombre': key_word,
                    'tipoPersona': 'jur',
                    'SoloActivos': 'false',
                    'pagina': page
                }

                try:
                    logging.info("page ->"+str(page))
                    response = requests.get(base_url, params=params, verify=False)

                    response.raise_for_status()
                    json_data = response.json()
                    print(json_data)
                    data.extend(json_data['procesos'])
                    if page >= json_data['paginacion']['cantidadPaginas']:
                        break
                    page += 1

                except requests.exceptions.HTTPError as http_err:
                    if response.status_code == 400:
                        logging.error(f"Bad request: {response.json()['Message']}")
                        return json.dumps({"error": f"Bad request: {response.json()['Message']}"}, ensure_ascii=False)
                    else:
                        logging.error(f"HTTP error occurred: {http_err}")
                        return json.dumps({"error": f"HTTP error occurred: {http_err}"}, ensure_ascii=False)
                except Exception as err:
                    logging.error(f"Unexpected error: {err}")
                    return json.dumps({"error": f"Unexpected error: {err}"}, ensure_ascii=False)

        else:
            return json.dumps([])

        # Normalize data to dataframe
        df = pd.json_normalize(data)

        # Fetch additional details and add to "Detalle" column
        df['Detalle'] = df['idProceso'].apply(fetch_additional_details)
        df['Sujetos'] = df['idProceso'].apply(fetch_sujetos)
        df['Actuaciones'] = df['idProceso'].apply(fetch_actuaciones)

        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii=False)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

def fetch_additional_details(idProceso):
    detail_url = f"https://consultaprocesos.ramajudicial.gov.co:448/api/v2/Proceso/Detalle/{idProceso}"
    try:
        response = requests.get(detail_url, verify=False)
        response.raise_for_status()
        detail_data = response.json()

        # Extracting specified keys and values
        keys = ['ponente', 'tipoProceso', 'claseProceso', 'subclaseProceso', 'recurso']
        detail_string = "\n".join([f"{key}: {detail_data[key]}" for key in keys if key in detail_data])

        return detail_string

    except requests.RequestException as err:
        logging.error(f"Error fetching additional details for idProceso={idProceso}: {err}")
        return None

def fetch_sujetos(idProceso):
    sujetos_url = f"https://consultaprocesos.ramajudicial.gov.co:448/api/v2/Proceso/Sujetos/{idProceso}"
    try:
        response = requests.get(sujetos_url, verify=False)
        response.raise_for_status()
        sujetos_data = response.json()

        # Extracting specified keys and values from each 'sujeto'
        formatted_sujetos = []
        for sujeto in sujetos_data.get('sujetos', []):
            tipoSujeto = sujeto.get('tipoSujeto', '')
            nombreRazonSocial = sujeto.get('nombreRazonSocial', '')
            formatted_sujetos.append(f"{tipoSujeto}: {nombreRazonSocial}")

        return "\n".join(formatted_sujetos)

    except requests.RequestException as err:
        logging.error(f"Error fetching sujetos for idProceso={idProceso}: {err}")
        return None

def fetch_actuaciones(idProceso):
    actuaciones_url = f"https://consultaprocesos.ramajudicial.gov.co:448/api/v2/Proceso/Actuaciones/{idProceso}"
    try:
        response = requests.get(actuaciones_url, verify=False)
        response.raise_for_status()
        actuaciones_data = response.json()

        # Extracting 'fechaActuacion' and 'actuacion' from each actuacion
        formatted_actuaciones = []
        for actuacion in actuaciones_data.get('actuaciones', []):
            fechaActuacion = actuacion.get('fechaActuacion', '')
            if fechaActuacion:
                fechaActuacion = fechaActuacion.split('T')[0]  # Extract only the date part
            act = actuacion.get('actuacion', '')
            formatted_actuaciones.append(f"{fechaActuacion}: {act}")

        return "\n".join(formatted_actuaciones)

    except requests.RequestException as err:
        logging.error(f"Error fetching actuaciones for idProceso={idProceso}: {err}")
        return None

#61
def webscraping_cabilveo_registro_de_regalos_a_funcionarios_publicos(key_word:str):
    try:
        url = 'https://cabilveo.org/wp-admin/admin-ajax.php?action=get_wdtable&table_id=39'
        get_nonce_url = 'https://cabilveo.org/registro-de-regalos-1/'
        response_get = requests.get(get_nonce_url, verify=False)
        soup = BeautifulSoup(response_get.text, 'lxml')
        nonce_input_tag = soup.find('input', {'id': 'wdtNonceFrontendEdit_39'})
        nonce = nonce_input_tag['value']

        print(f"Nonce Value: {nonce}")

        data = {
            'draw': 2,
            'length': -1,
            'columns[12][search][value]': '|',
            'wdtNonce': nonce,
        }
        
        response_post = requests.post(url, data=data, verify=False)
        print(f"Response Status Code: {response_post.status_code}")
        response_data = json.loads(response_post.text)['data']
        df = pd.DataFrame(response_data, columns = ["ID", "Organization", "FirstName", "LastName", "Year", "Month1", "Month2", "Gift", "Unknown1", "Value", "From", "Sector", "Unknown2", "Details"])
        
        # filter rows that contain the key_word in any column
        if key_word.strip():
            df = df[df.apply(lambda row: row.astype(str).str.lower().str.contains(key_word.lower()).any(), axis=1)]
        
        #save_to_csv('webscraping_cabilveo_registro_de_regalos_a_funcionarios_publicos', key_word, df)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data
        
    except requests.exceptions.RequestException as e:
        logging.error(f"There was an issue with the network connection: {str(e)}")
        return json.dumps({"error": f"There was an issue with the network connection: {str(e)}"})

    except AttributeError as e:
        logging.error(f"There was an issue with data attributes: {str(e)}")
        return json.dumps({"error": f"There was an issue with data attributes: {str(e)}"})

    except json.decoder.JSONDecodeError as e:
        logging.error(f"There was an issue with JSON decoding: {str(e)}")
        return json.dumps({"error": f"There was an issue with JSON decoding: {str(e)}"})

    except Exception as e:
        logging.error(f"An unexpected error occurred: {str(e)}")
        return json.dumps({"error": f"An unexpected error occurred: {str(e)}"})

#62
def webscraping_cabilveo_registro_de_viajes_realizados_por_funcionarios_publicos(key_word:str):
    url = 'https://cabilveo.org/wp-admin/admin-ajax.php?action=get_wdtable&table_id=36'
    get_nonce_url = 'https://cabilveo.org/registro-de-viajes-1/'
    
    try:
        response_get = requests.get(get_nonce_url, verify=False)
    except requests.exceptions.RequestException as e:
        logging.error(f"Error during GET request to {get_nonce_url} : {str(e)}")
        return json.dumps({"error": f"Error during GET request to {get_nonce_url} : {str(e)}"})

    try:
        soup = BeautifulSoup(response_get.text, 'lxml')
    except Exception as e:
        logging.error(f"Error during parsing HTML : {str(e)}")
        return json.dumps({"error": f"Error during parsing HTML : {str(e)}"})

    try:
        nonce_input_tag = soup.find('input', {'id': 'wdtNonceFrontendEdit_36'})
        nonce = nonce_input_tag['value']
    except TypeError as e:
        logging.error(f"Error during finding nonce value : {str(e)}")
        return json.dumps({"error": f"Error during finding nonce value : {str(e)}"})

    #print(f"Nonce Value: {nonce}")

    data = {
        'draw': 2,
        'length': -1,
        'columns[12][search][value]': '|',
        'wdtNonce': nonce,
    }

    try:
        response_post = requests.post(url, data=data, verify=False)
    except requests.exceptions.RequestException as e:
        logging.error(f"Error during POST request to {url} : {str(e)}")
        return json.dumps({"error": f"Error during POST request to {url} : {str(e)}"})

    try:
        response_data = json.loads(response_post.text)['data']
    except (json.JSONDecodeError, KeyError) as e:
        logging.error(f"Error during parsing JSON : {str(e)}")
        return json.dumps({"error": f"Error during parsing JSON : {str(e)}"})

    try:
        df = pd.DataFrame(response_data, columns = ["ID", "Organization", "FirstName", "LastName", "Country1", "City1", "Country2", "City2", "StartDate", "StartDay", "StartMonth", "StartYear", "EndDate", "EndDay", "EndMonth", "EndYear", "Duration", "CostsCoveredBy", "AdditionalCosts", "Purpose", "OtherDetails", "Decree", "Unknown1", "Unknown2", "Details"])
        
        if key_word.strip():
            df = df[df.apply(lambda row: row.astype(str).str.lower().str.contains(key_word.lower()).any(), axis=1)]

        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data

    except Exception as e:
        logging.error(f"Error: {str(e)}")
        return json.dumps({"error": f"{str(e)}"})


#63
def webscraping_registro_unico_de_proponentes(key_word:str):
    url = 'https://www.rues.org.co/RUP/ConsultaNIT_json'

    data = {
        'txtNIT': key_word
    }

    try:
        response = requests.post(url, data=data, verify=False)
        response.raise_for_status()  # Raises stored HTTPError, if one occurred
    except requests.exceptions.RequestException as e:
        logging.error(f"Error during POST request to {url} : {str(e)}")
        return json.dumps({"error": f"Error during POST request to {url} : {str(e)}"})

    try:
        response_data = json.loads(response.text)
        rows_data = response_data.get('rows', [])  # Extract 'rows' data from the response
    except (json.JSONDecodeError, KeyError) as e:
        logging.error(f"Error during parsing JSON : {str(e)}")
        return json.dumps({"error": f"Error during parsing JSON : {str(e)}"})

    try:
        df = pd.DataFrame(rows_data)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data
    except Exception as e:
        logging.error(f"Error: {str(e)}")
        return json.dumps({"error": f"{str(e)}"})

#64
def webscraping_sanciones_en_firme_superintendencia_financiera_de_colombia(key_word: str):
    try:
        url = 'https://www.superfinanciera.gov.co/SiriWeb/publico/sancion/lista_autoliquidacion.jsf'
        session = requests.Session()  # Create a session to persist cookies
        response = session.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        view_state = soup.find('input', {'name': 'javax.faces.ViewState'})['value']

        data_rows = []  # Move data_rows outside the loop

        while True:
            table = soup.find('table', {'id': 'contentSV:frm2:lista_destino'})
            column_names = [th.get_text() for th in table.find('thead').find_all('th')]

            for tr in table.find('tbody').find_all('tr'):
                data_row = []
                for td in tr.find_all('td'):
                    data_row.append(td.get_text().strip())
                data_rows.append(data_row)
            
            page_info = soup.find('div', {'class': 'tableCentro'}).get_text().strip()
            current_page, total_pages = map(int, re.findall(r'\d+', page_info))
            
            # Check if it's the last page
            if current_page >= total_pages:
                break

            form_data = {
                'autoScroll': '0,0',
                'contentSV:frm2_SUBMIT': '1',
                'javax.faces.ViewState': view_state,
                'contentSV:frm2:j_id_id29pc2': 'next',
                'contentSV:frm2:_idcl': 'contentSV:frm2:j_id_id29pc2next'
            }

            response = session.post(url, data=form_data)
            soup = BeautifulSoup(response.text, 'html.parser')
            view_state = soup.find('input', {'name': 'javax.faces.ViewState'})['value']  # Update the ViewState after loading the new page

        df = pd.DataFrame(data_rows, columns=column_names)

        if key_word != "":
            df = df[df.apply(lambda row: row.astype(str).str.lower().str.contains(key_word.lower()).any(), axis=1)]

        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii=False)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"}, ensure_ascii=False)

#65 (needs to be fixed to fetch page indexes > 1)
def webscraping_sanciones_historicas_superintendencia_financiera_de_colombia(key_word:str):
    url = 'https://wl.superfinanciera.gov.co/SiriWeb/publico/sancion/rep_sanciones_general_par.jsf'

    headers_get = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }

    with requests.Session() as s:  
        response = s.get(url, headers=headers_get, verify=False)
        soup = BeautifulSoup(response.text, 'html.parser')

        view_state = soup.find('input', {'id': 'javax.faces.ViewState'}).get('value')

        headers_post = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
        }

        payload = {
            'contentSV:frm2:idFechaDesde.day': '',
            'contentSV:frm2:idFechaDesde.month': -1,
            'contentSV:frm2:idFechaDesde.year': '',
            'contentSV:frm2:idFechaHasta.day': '',
            'contentSV:frm2:idFechaHasta.month': -1,
            'contentSV:frm2:idFechaHasta.year': '',
            'contentSV:frm2:j_id_id15pc2': '',
            'contentSV:frm2:j_id_id17pc2': key_word,
            'contentSV:frm2:j_id_id19pc2': '',
            'contentSV:frm2:numeroResolucion': '',
            'contentSV:frm2:j_id_id25pc2': '',
            'contentSV:frm2:j_id_id26pc2': 'Buscar',
            'autoScroll': '0,0',
            'contentSV:frm2_SUBMIT': 1,
            'javax.faces.ViewState': view_state
        }

        file_data = {key: (None, value) for key, value in payload.items()}

        response = s.post(url, headers=headers_post, files=file_data, verify=False)
        soup = BeautifulSoup(response.text, 'html.parser')


        # PARSE HTML!

        table = soup.find('table', {'id': 'contentSV:frm2:sancion_valores'})

        # Get the table body
        table_body = table.find('tbody', {'id': 'contentSV:frm2:sancion_valores:tbody_element'})

        # Initialize an empty list to store the rows of data
        data = []

        # Iterate over each row in the table body
        for row in table_body.find_all('tr'):
            # Get all the cells in the row
            cells = row.find_all('td')
            # Extract the text from each cell
            row_data = [cell.text.strip() for cell in cells]
            # Append the row data to the data list
            data.append(row_data)

        headers = [
            'Persona o Entidad Multada', 'Identificación', 'Clase de Sanción', 
            'Tipo de Sanción', 'Tema Clasificación', 'Número de resolución', 
            'Fecha', 'Cargo multado', 'Monto de Sanción', 'Fecha firmeza', 
            'Recurso Interpuso', 'Resolución que Resuelve el Recurso', 
            'Fecha Resolución Recurso', 'Descripción'
        ]

        # Initialize the index for pagination
        idx = 1
        print("INDEX:",idx)
        with open("payload1.json", 'w') as file:
            json.dump(payload, file, indent=4)

        with open("soup1.txt", 'w') as file:
            file.write(soup.prettify())

        while True:
            # Get the total pages from the HTML
            pagination_div = soup.find('div', {'class': 'tableCentro'})
            if pagination_div:
                match = re.search(r'Pagina (\d+) de (\d+)', pagination_div.text)
                if match:
                    current_page, total_pages = map(int, match.groups())
                    if current_page >= total_pages:
                        break  # We've reached the last page

            # Increment the index for the next page
            idx += 1
            print("INDEX:",idx)

            # Make the request for the next page if there is a next page
            if idx <= total_pages:
                # Update the payload to request the next page
                payload.pop('contentSV:frm2:j_id_id26pc2', None)  # Remove this attribute
                payload['contentSV:frm2:j_id_id100pc2'] = f'idx{idx}'
                payload['contentSV:frm2:_idcl'] = f'contentSV:frm2:j_id_id100pc2idx{idx}'
                payload.pop('contentSV:frm2:j_id_id17pc2', None)  # Remove this attribute
                payload['contentSV:frm2:j_id_id17pc2'] = key_word

                file_data = {key: (None, value) for key, value in payload.items()}

                # Extract the new view state value from the soup
                view_state = soup.find('input', {'id': 'javax.faces.ViewState'}).get('value')
                payload['javax.faces.ViewState'] = view_state  # Update the view state in the payload

                # Make the request for the next page
                response = requests.post(url, headers=headers_post, cookies=response.cookies, files=file_data, verify=False)
                soup = BeautifulSoup(response.text, 'html.parser')

                file_path = f'payload{idx}.json'
                with open(file_path, 'w') as file:
                    json.dump(payload, file, indent=4)

                with open(f"soup{idx}.txt", 'w') as file:
                    file.write(soup.prettify())

                # Get the table and its body
                table = soup.find('table', {'id': 'contentSV:frm2:sancion_valores'})
                table_body = table.find('tbody', {'id': 'contentSV:frm2:sancion_valores:tbody_element'})

                # Iterate over each row in the table body
                for row in table_body.find_all('tr'):
                    # Get all the cells in the row
                    cells = row.find_all('td')
                    # Extract the text from each cell
                    row_data = [cell.text.strip() for cell in cells]
                    # Append the row data to the data list
                    data.append(row_data)

        # Convert the data to a pandas DataFrame
        df = pd.DataFrame(data, columns=headers)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list)
        return json_data

#66
def webscraping_sanciones_proteccion_de_datos_personales_superintendencia_de_industria_y_comercio(key_word:str):
    try:
        url = "https://www.sic.gov.co/sanciones-proteccion-datos-personales-2022"
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')


        table = soup.find('table', {'class': 'table table-bordered table-responsive'})
        data = []
        rows = table.find_all('tr')

        for row in rows[1:]:
            cols = row.find_all('td')
            cols = [re.sub(' +', ' ', ele.text.strip().replace('\n', '').replace('\t', '')) for ele in cols]
            data.append(cols)

        df = pd.DataFrame(data, columns=['Sancionado / Investigado', 'Fecha', 'Título', 'Resolución', 'Estado'])

        if key_word != "":
            df = df[df.apply(lambda row: row.astype(str).str.lower().str.contains(key_word.lower()).any(), axis=1)]

        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii=False)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"}, ensure_ascii=False)

#67
def scraping_sentencias_de_caracter_mercantil_superintendencia_de_sociedades(key_word: str):
    url = "https://admin.es.prod.ssociedades.nuvu.cc/index_thesaurus/_search?pretty" #"https://admin.es.prod.ssociedades.nuvu.cc/index_thesaurus_aea.json"
    now = dt.now().strftime("%Y_%m_%d_%H_%M_%S")
    
    try:
        response = requests.get(url, verify=False)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        logging.error(f"Request to {url} failed: {e}")
        return json.dumps({"error": f"Request to {url} failed: {e}"}, ensure_ascii=False)
    
    try:
        json_data = response.json()
    except json.JSONDecodeError as e:
        logging.error(f"Failed to parse response as JSON: {e}")
        return json.dumps({"error": f"Failed to parse response as JSON: {e}"}, ensure_ascii=False)

    hits = json_data.get('hits', {}).get('hits', [])
    filtered_hits = [hit for hit in hits if key_word in str(hit)]
    return json.dumps(filtered_hits, ensure_ascii = False)

#68 key_word must be a year within the interval [1999, 2021]
def scraping_sentencias_a_companias_por_competencia_desleal(key_word:str):
    try:
        data_dict = {
            '1999': "/sentencias-competencia-desleal-1999",
            '2000': "/sentencias-competencia-desleal-2000", 
            '2001': "/sentencias-competencia-desleal-2001", 
            '2002': "/sentencias-competencia-desleal-2002",
            '2003': "/sentencias-competencia-desleal-2003", 
            '2004': "/sentencias-competencia-desleal-2004", 
            '2005': "/sentencias-competencia-desleal-2005",
            '2006': "/sentencias-competencia-desleal-2006", 
            '2007': "/sentencias-competencia-desleal-2007", 
            '2008': "/sentencias-competencia-desleal-2008", 
            '2009': "/sentencias-competencia-desleal-2009", 
            '2010': "/sentencias-competencia-desleal-2010", 
            '2011': "/sentencias-competencia-desleal-2011", 
            '2012': "/sentencias-competencia-desleal-2012",
            '2013': "/sentencias-competencia-desleal-2013", 
            '2014': "/sentencias-competencia-desleal-2014", 
            '2015': "/sentencias-competencia-desleal-2015", 
            '2016': "/sentencias-competencia-desleal-2016", 
            '2017': "/node/15921", 
            '2018': "/node/36866", 
            '2019': "/node/42210",
            '2020': "/sentencias-2020-0", 
            '2021': "/sentencia-2021",
        }
        
        all_data = []
        
        # Iterating over all the keys
        for current_key in data_dict.keys():
            logging.info("current key: %s", str(current_key))
            url = f"https://www.sic.gov.co{data_dict[current_key]}"
            response = requests.get(url, verify=False)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')

            # Your logic here
            table_class = "table pdos ptres" if current_key in ['2010', '2009', '2005', '2002', '2001'] else "table pdos" if current_key in ['2008','2007','2006', '2004', '2003'] else "table table-striped" if current_key not in ['2000', '1999'] else "table"
            table = soup.find("table", {"class": table_class})

            if table:
                for row in table.tbody.find_all("tr"):
                    # Your logic here
                    columns = row.find_all("td")

                    if current_key in ['2001', '2000', '1999']: # Handle 2001 and 2000 specifically
                        nombre = columns[0].get_text(strip=True)
                        demandante = columns[1].get_text(strip=True)
                        demandado = columns[2].get_text(strip=True)
                        asunto = columns[3].get_text(strip=True)
                        acceder_o_descargar = None
                    elif current_key in ['2009', '2008', '2005', '2004', '2003', '2002']:  # If it's 2009, 2008, 2005, 2004 or 2002, handle the row differently
                        nombre = columns[0].get_text(strip=True)
                        demandante = columns[1].get_text(strip=True)
                        demandado = columns[2].get_text(strip=True)
                        asunto = columns[3].get_text(strip=True)
                        acceder_o_descargar = [a["href"] for a in columns[4].find_all("a")] if len(columns) > 4 else None
                    else:
                        nombre = columns[0].get_text(strip=True) if len(columns) > 0 else None
                        demandante = columns[1].get_text(strip=True) if len(columns) > 1 else None
                        demandado = columns[2].get_text(strip=True) if len(columns) > 2 else None
                        asunto = columns[3].get_text(strip=True) if len(columns) > 3 else None

                        if len(columns) > 4:
                            if current_key in ['2020', '2021', '2019']:  # if it's 2020, 2021 or 2019, handle the "Acceder o Descargar" column differently
                                acceder_o_descargar = [a["href"] for p in columns[4].find_all("p") for a in p.find_all("a")]
                            else:
                                acceder_o_descargar = [a["href"] for a in columns[4].find_all("a")]
                        else:
                            acceder_o_descargar = None

                    if acceder_o_descargar:
                        acceder_o_descargar = [a if a.startswith('http') else url + a for a in acceder_o_descargar]

                    row_data = {
                        "Nombre": nombre,
                        "Demandante": demandante,
                        "Demandado": demandado,
                        "Asunto": asunto,
                        "Acceder o Descargar": acceder_o_descargar,
                        "Año": str(current_key)
                    }
                
                    all_data.append(row_data)

        # Filter the data by key_word
        #filtered_data = [item for item in all_data if key_word.lower() in item['Nombre'].lower() or key_word.lower() in item['Demandante'].lower() or key_word.lower() in item['Demandado'].lower() or key_word.lower() in item['Asunto'].lower()]
        df = pd.DataFrame(all_data)
        
        if key_word != "":
            df = df[df.apply(lambda row: row.astype(str).str.lower().str.contains(key_word.lower()).any(), axis=1)]
        
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii=False)
        return json_data

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        print(f"No data could be retrieved from: {url}")
    

# MEXICO
#70
def scraping_secretaria_de_hacienda_y_credito_publico_compranet(key_word: str):
    try:
        url = 'https://cnet.hacienda.gob.mx/servicios/consultaRUPC.jsf'
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
        }

        session = requests.Session()
        response = session.get(url, headers=headers)
        cookies = response.cookies
        soup = BeautifulSoup(response.text, 'html.parser')

        view_state = soup.find('input', {'name':'javax.faces.ViewState'}).get('value')
        data = {
            'javax.faces.partial.ajax': 'true',
            'javax.faces.source': 'consulta:btnBuscar',
            'javax.faces.partial.execute': '@all',
            'javax.faces.partial.render': 'formTabla:tabla consulta:pnlBuscar consulta:growl',
            'consulta:btnBuscar': 'consulta:btnBuscar',
            'consulta': 'consulta',
            'consulta:tipoSol_input': '1',
            'consulta:rfc': key_word,
            'consulta:razon': '',
            'consulta:rupc': '',
            'consulta:fechaDesde_input': '',
            'consulta:fechaHasta_input': '',
            'javax.faces.ViewState': view_state
        }

        response = session.post(url, headers=headers, data=data, cookies=cookies)
        root = ET.fromstring(response.content)
        html_string = root.find(".//update[@id='formTabla:tabla']").text

        soup = BeautifulSoup(html_string, 'html.parser')

        table_body = soup.find('tbody', {'id': 'formTabla:tabla_data'})
        rows = table_body.find_all('tr', {'role': 'row'}) if table_body else []
        
        data = []
        for row in rows:
            cols = row.find_all('div', {'class': 'ui-dt-c'})
            cols = [col.text.strip() for col in cols]
            data.append(cols)
        
        if not data:
            return json.dumps([])

        df = pd.DataFrame([data[0][:-1]], columns=['Name', 'Entity Type', 'Country Code', 'Country'])
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii=False)
        return json_data
    
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#71
def scraping_proveedores_y_contratistas_sancionados_secretaria_de_la_funcion_publica(key_word:str):
    try:
        key_word = key_word.upper()
        url = 'https://dgti-ees-i-particulares-sancionados-api-nv.apps.funcionpublica.gob.mx/'
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50',
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
            'Origin': 'https://directoriosancionados.apps.funcionpublica.gob.mx',
            'Referer': 'https://directoriosancionados.apps.funcionpublica.gob.mx/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
        }
        
        body = {
            "operationName":"getExpXDependencias",
            "variables":{
                "filtros":{
                    "nombre_razon_social":f"%{key_word}%",
                    "edossancion":[2,3]
                },
                "ordenCampo":"nombre_razon_social",
                "ordenSentido":"asc"
            },
            "query":"query getExpXDependencias($filtros: FiltrosInput!, $ordenCampo: ORDEN_CAMPO, $ordenSentido: ORDEN_SENTIDO) {\n  results(filtros: $filtros, ordenCampo: $ordenCampo, ordenSentido: $ordenSentido) {\n    numero_expediente\n    numexpediente_corto\n    nombre_razon_social\n    multa {\n      monto\n      monto_cf\n    }\n    plazo {\n      plazo_inha\n    }\n  }\n}"
        }
        
        response = requests.post(url, headers=headers, data=json.dumps(body))
        json_data = response.json()
        data = json_data['data']['results']
        df = pd.json_normalize(data)

        # Strip leading and trailing spaces
        df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii=False)
        return json_data
        
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#75
def scrape_single_page(url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
        }

        response = requests.get(url, headers=headers, verify=False)
        if response.status_code != 200:
            print("Failed to retrieve page")
            return None, None

        page_content = response.content
        soup = BeautifulSoup(page_content, 'html.parser')

        contracts = []
        for contract_div in soup.find_all('div', class_='index-list-item'):
            title_div = contract_div.find('div', class_='index-list-title')
            title = title_div.get_text(strip=True) if title_div else None

            region_span = contract_div.find('span', class_='flag-icon')
            region = region_span.get('title') if region_span else None

            institution_anchor = contract_div.find('a', title=lambda t: t and 'Comprador:' in t)
            institution = institution_anchor.get_text(strip=True) if institution_anchor else None

            provider_anchor = contract_div.find('a', title=lambda t: t and 'Proveedor/a:' in t)
            provider = provider_anchor.get_text(strip=True) if provider_anchor else None

            amount_p = contract_div.find('p', title=lambda t: t and 'Monto:' in t)
            amount = amount_p.get_text(strip=True) if amount_p else None

            date_p = contract_div.find('p', title=lambda t: t and 'Fecha:' in t)
            date = date_p.get_text(strip=True) if date_p else None

            procedure_type_p = contract_div.find('p', title=lambda t: t and 'Tipo de procedimiento:' in t)
            procedure_type = procedure_type_p.get_text(strip=True) if procedure_type_p else None

            contracts.append({
                'title': title,
                'region': region,
                'institution': institution,
                'provider': provider,
                'amount': amount,
                'date': date,
                'procedure_type': procedure_type
            })

        # Check if there is a next page
        next_page_a = soup.find('a', class_='page-link page-next')
        if next_page_a and next_page_a.get('href'):
            next_page_url = urljoin(url, next_page_a['href'])
        else:
            next_page_url = None

        return contracts, next_page_url
    
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

def scraping_quien_es_quien(key_word):
    if key_word == "":
        logging.error("A keyword is mandatory for this service.")
        return json.dumps({"error": "A keyword is mandatory for this service."})
    try:
        encoded_key_word = quote(key_word)
        base_url = f"https://www.quienesquien.wiki/es/buscador?name={encoded_key_word}"

        all_contracts = []
        next_page_url = base_url
        while next_page_url:
            contracts, next_page_url = scrape_single_page(next_page_url)
            if contracts is not None:
                all_contracts.extend(contracts)

        df = pd.DataFrame(all_contracts)
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data
    
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#ECUADOR
#76
def replace_values(obj):
    if isinstance(obj, list):
        for i in range(len(obj)):
            obj[i] = replace_values(obj[i])
    elif isinstance(obj, dict):
        for k in obj.keys():
            if isinstance(obj[k], str):
                obj[k] = obj[k].replace('\u0000', 'NULL')
            else:
                obj[k] = replace_values(obj[k])
    return obj

def scraping_consulta_de_procesos_judiciales_expel(key_word: str):
    if key_word == "":
        logging.error("A keyword is mandatory for this service.")
        return json.dumps({"error": "A keyword is mandatory for this service."})

    try:
        url = 'https://api.funcionjudicial.gob.ec/consulta/coincidencias?page=1&size=1000'
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
        }
        payload = {"texto": key_word}

        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()  # raise an exception in case of failure
        data = response.json()
        data = replace_values(data)  # replace unwanted sequences

        df = pd.DataFrame(data)
        
        if df.empty:
            print('No data received')
            return None
        
        data_list = df.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#77
def scraping_busqueda_proveedores_gobierno_ecuador(key_word:str):
    if key_word == "":
        logging.error("A keyword is mandatory for this service.")
        return json.dumps({"error": "A keyword is mandatory for this service."})

    key_word_encoded = quote(key_word)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
    }

    all_data = pd.DataFrame()

    for year in range(2015, 2024):  # loop over years from 2015 to 2023
        url1 = f'https://datosabiertos.compraspublicas.gob.ec/PLATAFORMA/procedimientos?local=1&year={year}&page=1'
        response1 = requests.get(url1, headers=headers)
        
        if 'Set-Cookie' in response1.headers:
            cookie_value = response1.headers['Set-Cookie']
            token = cookie_value.split(';')[0]
        else:
            print('Set-Cookie header not found')
            return

        headers['X-XSRF-TOKEN'] = token

        page = 1
        while True:
            url2 = f'https://datosabiertos.compraspublicas.gob.ec/PLATAFORMA/api/search_ocds?local=1&year={year}&search={key_word_encoded}&page={page}'
            response2 = requests.get(url2, headers=headers)

            if response2.status_code != 200:
                print(f'Request failed with status code {response2.status_code}')
                break

            data = response2.json()

            if 'data' not in data:
                print('No data in response')
                break

            df = pd.DataFrame(data['data'])
            all_data = pd.concat([all_data, df])

            if page >= data['pages']:
                break

            page += 1  # go to the next page

    data_list = all_data.to_dict(orient='records')
    json_data = json.dumps(data_list, ensure_ascii=False)
    return json_data

#78 INCOMPLETO -> CAPTCHA DE IMAGENES
def scraping_consulta_ruc_servicio_de_rentas_internas(key_word: str):
    url = f'https://srienlinea.sri.gob.ec/sri-catastro-sujeto-servicio-internet/rest/ConsolidadoContribuyente/obtenerPorNumerosRuc?&ruc={key_word}'

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
    }

    response = requests.get(url, headers=headers)

    print(response.text)



# BOLIVIA
#79
def scraping_gaceta_electronica_del_registro_de_comercio_de_bolivia(key_word:str):
    try:
        if key_word == "":
            return json.dumps([])

        base_url = 'https://servicios.seprec.gob.bo/api/publicaciones'
        
        headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-US,en;q=0.9,es;q=0.8',
            'Content-Type': 'application/json',
            'Origin': 'https://gacetadecomercio.gob.bo',
            'Referer': 'https://gacetadecomercio.gob.bo/',
            'Sec-Ch-Ua': '"Microsoft Edge";v="113", "Chromium";v="113", "Not-A.Brand";v="24"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
        }
        
        payload = {
            "fechaInicial": "",
            "fecha": "",
            "fechaFinal": "",
            "categoria": "",
            "texto": "",
            "razonSocial": key_word,
            "tipoPublicacion": "",
            "matricula": "",
            "resumen": "",
            "limite": 50,
            "pagina": 1
        }
        
        response = requests.post(base_url, headers=headers, data=json.dumps(payload), verify=False)
        
        if str(response.status_code).startswith('2'):
            print("Success!")
            data = response.json()
            df = pd.json_normalize(data['datos']['filas'], sep='_')
            
            total_records = data['datos']['total']
            pages = math.ceil(total_records / 50)
            
            for page in range(2, pages + 1):
                payload['pagina'] = page
                response = requests.post(base_url, headers=headers, data=json.dumps(payload), verify=False)
                if str(response.status_code).startswith('2'):
                    data = response.json()
                    df_temp = pd.json_normalize(data['datos']['filas'], sep='_')
                    df = pd.concat([df, df_temp])
                else:
                    return json.dumps({"error": f"Response status code: {response.status_code} at page {page}"})
            
            # Adding this line to replace all multiple spaces in 'resumen' with a single space
            df['resumen'] = df['resumen'].apply(lambda x: re.sub(' +', ' ', x))
            
            data_list = df.to_dict(orient='records')
            json_data = json.dumps(data_list, ensure_ascii = False)
            return json_data
        else:
            print("Response status code:", response.status_code)
            print("Response body:", response.text)

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#80
def scraping_busqueda_resoluciones_jurisprudencia_bolivia(key_word: str):
    base_url = "https://jurisprudencia.tsj.bo/resoluciones_avanzado"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50'
    }
    
    params = {
        "term": key_word,
        "proceso": "",
        "id_sala": "",
        "gestion": "",
        "id_tipo_res": "",
        "id_forma_res": "",
        "id_magistrado": "",
        "departamento": "",
        "nro_resolucion": "",
        "nro_expediente": "",
        "demandante": "",
        "demandado": "",
        "page": 1
    }

    df_all = pd.DataFrame()

    while True: # Iterate until there's no more pages left
        response = requests.get(base_url, headers=headers, params=params, verify=False)
        if str(response.status_code).startswith('2'):
            print("Success!")
            data = response.json()["data"]["data"]
            df = pd.DataFrame(data)
            df_all = pd.concat([df_all, df]) # Append the new data to the total DataFrame
            
            if response.json()["data"]["next_page_url"]: # If there's a next page
                params["page"] += 1 # Increase the page parameter for the next request
            else:
                break # Break the loop if there's no next page
        else:
            print("Response status code:", response.status_code)
            print("Response body:", response.text)
            break # Break the loop if the response is not successful

    for col in df_all.columns:
        #df_all[col] = df_all[col].apply(lambda x: re.sub(r'[^\w\s]', '', str(x)) if isinstance(x, str) else x)
        df_all[col] = df_all[col].apply(lambda x: re.sub(' +', ' ', str(x)) if isinstance(x, str) else x)
        df_all[col] = df_all[col].apply(lambda x: x.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ') if isinstance(x, str) else x)
        
    data_list = df_all.to_dict(orient='records')
    json_data = json.dumps(data_list, ensure_ascii = False)
    return json_data

#81
def proord(A, c, s):
    i = len(A)
    B = s
    if i % 2 == 0:
        j = i // 2 - 1
    else:
        j = i // 2

    y = 0
    z = [0] * len(A)

    for u in range(len(A)):
        z[u] = 0

    for v in range(c, j):
        for t in range(i):
            y = y + B
            if y >= i:
                y = y - i
            z[t] = A[y]

        for t in range(i):
            A[t] = z[t]

    if (i == 3 and s == 2) or (i == 4 and s == 3) or (i == 7 and s == 6) or (i == 8 and s == 7) or (i == 12 and s == 11) or (i == 15 and s == 14) or (i == 16 and s == 15) or (i == 19 and s == 18) or (i == 20 and s == 19):
        for u in range(len(A)):
            z[u] = 0
            z[u] = A[u]

        k = 0
        for t in range(i - 1, -1, -1):
            A[k] = z[t]
            k = k + 1

    if (i == 3 and s == 1) or (i == 4 and s == 1):
        for u in range(len(A)):
            z[u] = 0
            z[u] = A[u]

        k = 0
        A[0] = z[i - 1]
        for t in range(1, i):
            A[t] = z[t - 1]

    return A

def scraping_sicoes_contratos_resueltos(empresa:str, nit:str):
    try:
        if nit is None:
            nit = ""

        if empresa is None:
            empresa = ""
        
        if nit == "" and empresa == "":
            return json.dumps([])

        page_counter = 1
        
        full_data = pd.DataFrame(columns = ['NIT/CI', 'Empresa/Persona Contratada', 'Entidad contratante', 'Objeto de la contratación', 'Monto del Contrato (Bs)',
                    'Fecha de suscripción', 'Fecha de resolución', 'Causante (según la entidad)', 'Causal', 'Javalink'])

        pages = 1
        
        while True: 
            with requests.session() as req:
                
                get_cookie = req.get('https://www.sicoes.gob.bo/portal/index.php', verify = False, headers = header)
                get_cookie = get_cookie.cookies.get_dict()
                get_cookie = ';'.join(x + '=' + y for x, y in get_cookie.items())
                
                value = req.get('https://www.sicoes.gob.bo/portal/contrataciones/busqueda/contResueltos.php', verify = False, headers = header)
                value = BeautifulSoup(value.content, 'html.parser')
                value = value.find_all("input", {'name':'B903A6B7'})[0]['value']
                
                api_headers = {'Accept':'application/json, text/javascript, */*; q=0.01', 'Accept-Encoding': 'gzip, deflate, br', 
                            'Accept-Language': 'en-US,en;q=0.9,es;q=0.8',
                            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
                            'Cookie': get_cookie, 'Referer': 'https://www.sicoes.gob.bo/portal/contrataciones/busqueda/contResueltos.php',
                            'Host':'www.sicoes.gob.bo', 'Origin': 'https://www.sicoes.gob.bo', 'Connection': 'keep-alive'}
                url = 'https://www.sicoes.gob.bo/portal/contrataciones/operacion.php'
                
                time_now = str(time.time())
                time_now = time_now[:14]
                time_now = time_now.replace('.', '')
                payload_2 = {'opetpo':'contResueltos','tpoope':'Simple','time':time_now}
                
                url_2 = 'https://www.sicoes.gob.bo/portal/contrataciones/operacion2.php'
                resp = req.post(url_2, verify = False, headers = api_headers, data = payload_2)
                resp_data = json.loads(resp.content)  
                a = resp_data['a']
                b = resp_data['b']
                data_columns = resp_data['sectorsec']
                
                data_columns = proord(data_columns, a, b)
            
                payload = {'empresa': empresa ,'nit': nit, 'r1': '%', 'B903A6B7': value,'operacion': 'contResueltos', 'nroRegistros': '10', 'draw': page_counter,
                        'start': '0', 'length': '10'}

                
                response = req.post(url, verify = False, headers = api_headers, data = payload)
            
                json_data = json.loads(response.content.decode("utf-8"))

                data_list = json_data['data']

                if not data_list:  # Break the loop if no data found
                    break
                
                for item in data_list:
                    decoded_item = {urllib.parse.unquote(key): [urllib.parse.unquote(value)] for key, value in item.items()}
                    df = pd.DataFrame.from_dict(decoded_item)
                    df = df[data_columns]
                    df.columns = ['NIT/CI', 'Empresa/Persona Contratada', 'Entidad contratante', 'Objeto de la contratación', 'Monto del Contrato (Bs)',
                                'Fecha de suscripción', 'Fecha de resolución', 'Causante (según la entidad)', 'Causal', 'Javalink']
                    
                    full_data = pd.concat([full_data, df], axis = 0)

                logging.info("page counter: " + str(page_counter))
                page_counter += 1
                
        full_data.reset_index(inplace = True, drop = True)
        full_data = full_data.drop(columns = ['Javalink'])
        data_list = full_data.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})



#82 
def scraping_sicoes_desistimientos(empresa:str, nit:str):
    try:
        if nit is None:
            nit = ""

        if empresa is None:
            empresa = ""
        
        if nit == "" and empresa == "":
            return json.dumps([])

        page_counter = 1

        full_data = pd.DataFrame(columns = ['NIT/CI', 'Empresa o Persona Juridica', 'Objeto de la contratación', 'Tipo de Desistimiento', 'Motivo',
                    'Fecha', 'Aceptado por la entidad', 'Javalink'])

        while True:
            with requests.session() as req:

                get_cookie = req.get('https://www.sicoes.gob.bo/portal/index.php', verify = False, headers = header)
                get_cookie = get_cookie.cookies.get_dict()
                get_cookie = ';'.join(x + '=' + y for x, y in get_cookie.items())

                value = req.get('https://www.sicoes.gob.bo/portal/contrataciones/busqueda/desistimientoCont.php', verify = False, headers = header)
                value = BeautifulSoup(value.content, 'html.parser')
                value = value.find_all("input", {'name':'B903A6B7'})[0]['value']

                api_headers = {'Accept':'application/json, text/javascript, */*; q=0.01', 'Accept-Encoding': 'gzip, deflate, br', 
                            'Accept-Language': 'en-US,en;q=0.9,es;q=0.8',
                            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
                            'Cookie': get_cookie, 'Referer': 'https://www.sicoes.gob.bo/portal/contrataciones/busqueda/desistimientoCont.php',
                            'Host':'www.sicoes.gob.bo', 'Origin': 'https://www.sicoes.gob.bo', 'Connection': 'keep-alive'}
                url = 'https://www.sicoes.gob.bo/portal/contrataciones/operacion.php'

                time_now = str(time.time())
                time_now = time_now[:14]
                time_now = time_now.replace('.', '')
                payload_2 = {'opetpo':'desistimientoCont','tpoope':'Simple','time':time_now}

                url_2 = 'https://www.sicoes.gob.bo/portal/contrataciones/operacion2.php'
                resp = req.post(url_2, verify = False, headers = api_headers, data = payload_2)
                resp_data = json.loads(resp.content)  
                a = resp_data['a']
                b = resp_data['b']
                data_columns = resp_data['sectorsec']

                data_columns = proord(data_columns, a, b)

                payload = {'empresa': empresa ,'nit': nit, 'B903A6B7': value,'operacion': 'desistimientoCont', 'nroRegistros': '10', 'draw': page_counter,
                        'start': '0', 'length': '10'}

                response = req.post(url, verify = False, headers = api_headers, data = payload)

                json_data = json.loads(response.content.decode("utf-8"))

                data_list = json_data['data']

                if not data_list:  # Break the loop if no data found
                    break

                for item in data_list:
                    decoded_item = {urllib.parse.unquote(key): [urllib.parse.unquote(value)] for key, value in item.items()}
                    df = pd.DataFrame.from_dict(decoded_item)
                    df = df[data_columns]
                    df.columns = ['NIT/CI', 'Empresa o Persona Juridica', 'Objeto de la contratación', 'Tipo de Desistimiento', 'Motivo',
                                'Fecha', 'Aceptado por la entidad', 'Javalink']

                    full_data = pd.concat([full_data, df], axis = 0)

                logging.info("page counter: " + str(page_counter))
                page_counter += 1

        full_data.reset_index(inplace = True, drop = True)
        full_data = full_data.drop(columns = ['Javalink'])
        data_list = full_data.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

#83
def scraping_sicoes_inhabilitadas(entidad:str=None):
    try:
        if entidad is None:
            entidad = ""

        page_counter = 1
        
        #DataFrame
        full_data = pd.DataFrame(columns = ['Nombre de la Entidad', 'Nombre del Departamento', 'Número de Procesos Pendientes', 'Javalink'])
        
        while True:
            with requests.session() as req:
                
                #Getting Cookie from Main Page
                get_cookie = req.get('https://www.sicoes.gob.bo/portal/index.php', verify = False, headers = header)
                get_cookie = get_cookie.cookies.get_dict()
                get_cookie = ';'.join(x + '=' + y for x, y in get_cookie.items())
                
                #Getting Value for Post
                value = req.get('https://www.sicoes.gob.bo/portal/incumplidos/incPacEstProceso.php?tipo=estadoProceso', verify = False, headers = header)
                value = BeautifulSoup(value.content, 'html.parser')
                value = value.find_all("input", {'name':'B903A6B7'})[0]['value']
                
                #Get Data
                api_headers = {'Accept':'application/json, text/javascript, */*; q=0.01', 'Accept-Encoding': 'gzip, deflate, br', 
                            'Accept-Language': 'en-US,en;q=0.9,es;q=0.8',
                            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
                            'Cookie': get_cookie, 'Referer': 'https://www.sicoes.gob.bo/portal/contrataciones/busqueda/contResueltos.php',
                            'Host':'www.sicoes.gob.bo', 'Origin': 'https://www.sicoes.gob.bo', 'Connection': 'keep-alive'}
                url = 'https://www.sicoes.gob.bo/portal/incumplidos/operacion.php'
                
                #Mimic Page Settings
                time_now = str(time.time())
                time_now = time_now[:14]
                time_now = time_now.replace('.', '')
                payload_2 = {'opetpo':'estadoProceso','tpoope':'Simple','time':time_now}
                
                url_2 = 'https://www.sicoes.gob.bo/portal/incumplidos/operacion2.php'
                resp = req.post(url_2, verify = False, headers = api_headers, data = payload_2)
                resp_data = json.loads(resp.content)  
                a = resp_data['a']
                b = resp_data['b']
                data_columns = resp_data['sectorsec']
                
                data_columns = proord(data_columns, a, b)
            
                #Main Data Requests (Arguments)
                payload = {'entidad': entidad, 'B903A6B7': value,'operacion': 'estadoProceso', 'nroRegistros': '10', 'draw': page_counter,
                        'start': '0', 'length': '10'}
                
                response = req.post(url, verify = False, headers = api_headers, data = payload)
            
                #Loading JSON
                json_data = json.loads(response.content.decode("utf-8"))
                
                #Total Records
                records = json_data['recordsTotal']
                pages = math.ceil(records / 10)
                
                #Getting the data
                data_list = json_data['data']

                if not data_list:
                    break

                for item in data_list:
                    decoded_item = {urllib.parse.unquote(key): [urllib.parse.unquote(value)] for key, value in item.items()}
                    df = pd.DataFrame.from_dict(decoded_item)
                    df = df[data_columns]
                    df.columns =  ['Nombre de la Entidad', 'Nombre del Departamento', 'Número de Procesos Pendientes', 'Javalink']
                    
                    #Concat resuls
                    full_data = pd.concat([full_data, df], axis = 0)
        
                logging.info("page counter: " + str(page_counter))
                page_counter += 1

        full_data.reset_index(inplace = True, drop = True)
        full_data = full_data.drop(columns = ['Javalink'])
        save_to_csv("scraping_sicoes_inhabilitadas",entidad,full_data)
        data_list = full_data.to_dict(orient='records')
        json_data = json.dumps(data_list, ensure_ascii = False)
        return json_data
    
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        return json.dumps({"error": f"An error occurred: {str(e)}"})

# COSTA RICA
# ... TODO

# EL SALVADOR
# ... TODO

# FRANCIA

#92
def scraping_french_national_freeze_registry(key_word: str):
    base_url = 'https://gels-avoirs.dgtresor.gouv.fr/List'

    session = requests.Session()
    response = session.get(base_url)

    soup = BeautifulSoup(response.text, 'html.parser')
    token = soup.find('input', {'name': '__RequestVerificationToken'}).get('value')

    data = {
        'QueryNomPrenomAlias': key_word,
        'QueryDateNaissance': "",
        'QueryTypeNature': "",
        '__RequestVerificationToken': token
    }
    
    response = session.post(base_url, data=data)
    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table', {'id': 'tableGels'})

    headers = [header.text for header in table.find('tr').find_all('th')]
    headers = headers[:-1]  # Exclude the last header "Search"
    
    df = pd.DataFrame(columns=headers)
    data_list = []
    for row in table.find_all('tr')[1:]:
        data = dict()
        for header, cell in zip(headers, row.find_all('td')[:-1]):  # Exclude the last cell "Search"
            data[header] = cell.text.strip()
        data_list.append(data)
    df = pd.DataFrame(data_list)

    data_list = df.to_dict(orient='records')
    json_data = json.dumps(data_list, ensure_ascii=False)
    return json_data

#111
def clean_dignatarios_list(dignatarios_list):
    return [dignatario.replace('\n', '').replace('\r', '') for dignatario in dignatarios_list]

def scraping_panama_empresas_inhabilitadas(key_word:str):
    base_url = "https://www.panamacompra.gob.pa/Security/AmbientePublico.asmx/proveedoresInhabilitados"

    headers = {
        "Accept": "application/json;charset=utf-8",
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "Referer": "https://www.panamacompra.gob.pa/Inicio/",
        "Sec-Ch-Ua": '"Not.A/Brand";v="8", "Chromium";v="114", "Microsoft Edge";v="114"',
        "Sec-Ch-Ua-Mobile": "?1",
        "Sec-Ch-Ua-Platform": "Android",
        "User-Agent": 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36 Edg/114.0.1823.58'
    }
    
    payload = {
        "METHOD": "0",
        "VALUE": "{}"
    }

    session = requests.Session()
    response = session.post(base_url, headers=headers, data=payload)
    
    data = response.json()  
    df = pd.DataFrame(data["listNews"])

    if key_word != "":
        df = df[df.apply(lambda row: row.astype(str).str.lower().str.contains(key_word.lower()).any(), axis=1)]

    df.replace(to_replace=[r"\t|\n|\r"], value=[""], regex=True, inplace=True)
    df['dignatarios'] = df['dignatarios'].apply(clean_dignatarios_list)
    json_data = json.dumps(df.to_dict(orient='records'), ensure_ascii = False)
    return json_data

#118
def scraping_UK_sanctions_list(key_word:str):

    if key_word == "":
        return json.dumps([])

    base_url = "https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/1165013/UK_Sanctions_List.ods"
    response = requests.get(base_url)
    assert response.status_code == 200, 'Failed to download the file'
    
    ods_data = io.BytesIO(response.content)
    
    df = pd.read_excel(ods_data, engine="odf", header=2)
    
    # Convert all columns to string
    df = df.astype(str)

    df = df[df.apply(lambda row: row.str.contains(key_word).any(), axis=1)]
    
    data_list = df.to_dict(orient='records')
    json_data = json.dumps(data_list, ensure_ascii = False)
    return json_data


#134
def scraping_asamblea_nacional_venezuela(keyword:str):
    base_url = "https://www.asambleanacional.gob.ve/diputados"
    page = 1
    data = []
    
    while True:
        url = f"{base_url}?page={page}"
        response = requests.get(url)
        soup = BeautifulSoup(response.content, 'html.parser')
        divs = soup.find_all('div', class_='text-diputado-slider')
        
        if not divs:
            break
        
        for div in divs:
            name = div.find('a').text.strip()
            party = div.find('small').find('b').text.strip()
            state = div.find('small').find_next('small').text.strip()
            
            data.append({'Name': name, 'Party': party, 'State': state})
        
        page += 1
    
    json_data = json.dumps(data, ensure_ascii=False)
    return json_data

#133
def scraping_poderopedia_venezuela(keyword: str, objectType: str):

    base_urls = {
        'personas': 'https://poderopediave.org/personas/',
        'empresas': 'https://poderopediave.org/empresas/',
        'organizaciones': 'https://poderopediave.org/organizaciones/'
    }

    if objectType not in base_urls.keys():
        return 'Tipo de objeto inválido. Los tipos válidos son: personas, empresas, organizaciones'
    
    base_url = base_urls[objectType]
    objects = []
    session = requests.Session()  # Start a requests Session

    response = session.get(base_url, verify=False)
    response.encoding = response.apparent_encoding
    cookies = session.cookies.get_dict()  # Get cookies as a dictionary
    page = 1

    while True:
        if page > 1:
            url = f"{base_url}page/{page}/?tid&ename={keyword}"
        else:
            url = f"{base_url}?tid=&ename={keyword}"
        logging.info("url: " + url)
        
        ua = UserAgent()
        headers = {'User-Agent': ua.random}
        response = session.get(url, headers=headers, cookies=cookies, verify=False)
        response.encoding = response.apparent_encoding
        content = response.text
        soup = BeautifulSoup(content, "html.parser")
        articles = soup.find_all("article")

        if not articles:
            break

        for article in articles:
            name = article.find("h2").text
            taxonomy_labels = article.find_all(class_="pp-taxonomy-label")
            taxonomies = ", ".join([label.text.strip() for label in taxonomy_labels if label.text.strip() != "\\"])
            
            if objectType == 'personas':
                obj = {
                    "name": name,
                    "taxonomies": taxonomies
                }
            else:
                obj = {
                    "name": name,
                    "type": taxonomies
                }
            objects.append(obj)
        page += 1
    json_data = json.dumps(objects, ensure_ascii=False)

    return json_data

# COSTA RICA

# 135
def scraping_ministerio_economia_industria_y_comercio(keyword, year):
    file_type = '.csv'
    base_url = 'https://www.meic.go.cr/web/761/datos-abiertos/pyme/registro-de-empresas.php'
    
    response = requests.get(base_url, verify=False)
    if response.status_code != 200:
        print(f"Failed to get the page. Status code: {response.status_code}")
        return []
    
    soup = BeautifulSoup(response.text, 'html.parser')
    links = soup.find_all('a', href=True)
    file_links = [link['href'] for link in links if file_type in link['href'] and str(year) in link['href']]
    
    results = []
    
    for file_link in file_links:
        print(f"Processing {file_link}")
        
        if file_link.startswith("/"):
            file_link = base_url.rsplit("/", 1)[0] + file_link
        
        response = requests.get(file_link, verify=False)
        if response.status_code != 200:
            print(f"Failed to get the file {file_link}. Status code: {response.status_code}")
            continue

        try:
            df = pd.read_csv(io.StringIO(response.text), encoding="latin1", sep=";", on_bad_lines='skip')
        except pd.errors.ParserError as e:
            print(f"Parser error with file {file_link}: {str(e)}")
            continue
        
        df = df.applymap(lambda x: x.replace("ń", "n") if isinstance(x, str) else x)
        df = df.fillna("")
        
        mask = df.apply(lambda col: col.str.contains(keyword, case=False, na=False) if col.dtype == "O" else False)
        matching_rows = df[mask.any(axis=1)]
        
        if not matching_rows.empty:
            for _, row in matching_rows.iterrows():
                # Concatenating the entire row into a single string with key:value pairs
                row_data = " \n ".join([f"{key}: {value}" for key, value in row.items()])
                results.append({
                    "data": row_data,
                    "filePath": file_link
                })
    
    return json.dumps(results, ensure_ascii=False)



if __name__ == "__main__":
    print("WebscrappingService __main__") 




