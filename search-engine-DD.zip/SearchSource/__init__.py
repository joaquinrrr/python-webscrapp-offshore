import json
import logging
import azure.functions as func
import os
import pandas as pd

from pydantic import BaseModel, ValidationError
from typing import Dict, Any, Optional
from .service import WebscrappingService as webscrapping_service


dir_path = os.path.dirname(os.path.realpath(__file__))
file_path_to_background_check_service_names = os.path.join(dir_path, "BackgroundCheckSites.json")
with open(file_path_to_background_check_service_names, "r") as f:
    backgroundCheckSites = json.load(f)

class SearchPayload(BaseModel):
    keyword: str
    site: str
    orderByPermanentReferenceNumber: Optional[bool] = None
    year: Optional[str] = None
    nit: Optional[str] = None
    objectType: Optional[str] = None

def main(req: func.HttpRequest) -> func.HttpResponse:

    logging.info("\n")

    try:
        payload = SearchPayload.parse_raw(req.get_body().decode())
    except ValidationError as e:
        return func.HttpResponse(body=f"Invalid input: {e}", status_code=400)

    service_name = backgroundCheckSites.get(payload.site)
    logging.info(f"Service name to be triggered: {service_name}")

    if not service_name:
        return func.HttpResponse(body=f"Service name {service_name} not found", status_code=404)

    service = getattr(webscrapping_service, service_name, None)

    if not service:
        return func.HttpResponse(body=f"Service {service_name} not found", status_code=404)

    logging.info(f"Service ->: {service}")

    # certain source services have different input parameters than just key_word
    if payload.site in ["81","82"]: # sites that need keyword or NIT code
        result = service(payload.keyword, payload.nit)

    elif payload.site in ["133"]: # sites that need keyword and objectType
        result = service(payload.keyword, payload.objectType)

    elif payload.site in ["135"]:
        result = service(payload.keyword, payload.year)

    else:
        result = service(payload.keyword)

    # print results (for testing purposes)
    # logging.info(f"Results: \n {result}")

    if isinstance(result, pd.DataFrame):
        result = result.to_dict('records')
    
    return func.HttpResponse(body=result, status_code=200)
    #return func.HttpResponse(body=json.dumps({"status": "success", "message": f"Webscraping {payload.site} with keyword {payload.keyword}.", "data": result}), status_code=200)
