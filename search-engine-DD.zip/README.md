# Azure Function endpoint

https://searchsourcedd.azurewebsites.net/api/searchsource

# JSON Body:

{
    "keyword": "FINANCIERA",
    "site": "64"
}

# List of available service codes -> BackgroundCheckSites.JSON


